Yahoo CRM — Hostinger staging upload

Upload the CONTENTS of the staging ZIP into public_html. index.html must sit directly in public_html, next to .htaccess, api, assets, database, storage, uploads, and setup.php. Do not leave the files inside an extra folder.

The site runs on PHP 8.1+ and MySQL. The server does not need Node.js, Express, or MongoDB.

This ZIP does not contain config.php, database passwords, or a setup key. Create those on the server.

HOSTINGER DATABASE

1. hPanel → Websites → Manage → PHP configuration. Set PHP to 8.1 or newer.
2. hPanel → Databases → MySQL Databases.
3. Create a new database. Use an empty database. Do not import into a database that already has tables.
4. Create a database user with a strong password.
5. Add that user to the database with All Privileges.
6. The host name shown by Hostinger is usually localhost. Copy the database name, user, and host exactly.
7. Open phpMyAdmin for that database.
8. Import database/schema.sql from this package. The import creates tables and foreign keys only. It does not create a login.

CONFIGURATION

1. In Hostinger File Manager, turn on hidden files and open public_html.
2. Copy config.sample.php to config.php in public_html.
3. Edit config.php on the server. Set:
   db_host     the host from hPanel, usually localhost
   db_name     the database name
   db_user     the database user
   db_pass     the database password
   setup_key   a random string of at least 16 characters
4. Do not put those values in the ZIP or in this README.
5. config.php and config.sample.php are denied by .htaccess. Each file also stops if it is requested directly.

UPLOAD

1. Upload the ZIP into public_html and extract it there, or upload the files yourself.
2. Confirm these paths exist:
   public_html/index.html
   public_html/.htaccess
   public_html/.user.ini
   public_html/api/index.php
   public_html/database/schema.sql
   public_html/setup.php
   public_html/config.php
3. storage/ and uploads/ must be writable by PHP. 755 is enough on Hostinger if the owner is the PHP user. Use 775 only if check-in or import later fails with a permission error.

HEALTH CHECK

Open this URL in the browser, using the real domain:

https://YOUR-DOMAIN/api/health

A successful response is JSON like:

{"success":true,"status":"ok","database":"connected","data":{"status":"ok","mode":"mysql","database":true}}

data.mode must be mysql. If it says the database is disconnected, fix config.php and import schema.sql before continuing. Sign-in will not work until this check passes.

FIRST ACCOUNT

1. Open https://YOUR-DOMAIN/setup.php
2. Enter the setup_key from config.php, plus the super admin name, email, employee code, and a password of at least 10 characters.
3. A wrong setup key does not create an account.
4. On success, setup.php deletes itself. Open https://YOUR-DOMAIN/setup.php again. It must not show the setup form.
5. If the success page says the file could not delete itself, delete setup.php in File Manager. While any user exists, setup.php refuses to create another account.
6. Sign in at https://YOUR-DOMAIN/ with the new email or employee code.

ROLE CHECKLIST

Create the records in this order. Use passwords of at least 8 characters for company admins, team leads, and employees. The first super admin password must be at least 10 characters.

super_admin
- Sign in and open /super-admin.
- Create a company.
- Create one company admin for that company and assign the company.
- Create one team lead and one employee in that company.
- Open /api/leads. Creating a lead as super_admin is refused.
- Sign out.

admin (company admin)
- Sign in.
- Open Dashboard. The chart must come from the API, not a fixed demo week.
- Create a team.
- Open Leads. Create a lead, assign it, add a note, export, and import a small file.
- Open Attendance, Calls, Follow-ups, Site visits, Properties, Reports, Settings, and Audit.
- Save office hours in Settings.
- Campaigns: save a draft, activate it, and pause it. Enrollment does not send WhatsApp.
- Settings → WhatsApp must say it is not live.
- Open /my-attendance and check in, start a break, end the break, and check out.
- Sign out.

team_lead
- Sign in.
- Leads shows only that team lead and their team.
- Calls, follow-ups, site visits, and attendance are limited to that team.
- Reports opens for their company.
- Campaigns returns a permission error. Campaign management is limited to super_admin and admin.
- Sign out.

employee
- Sign in. The home page is the employee workspace.
- Only leads assigned to that employee are listed.
- Log a call, complete a follow-up, and schedule a site visit on an assigned lead.
- Check in and check out from My attendance.
- A lead owned by someone else must not open.
- Sign out.

WHAT IS NOT LIVE

- WhatsApp messages are not sent. POST /api/whatsapp/send returns 503.
- Call length is what the employee enters. No phone provider verifies it.
- The nurturing screen cannot create a sequence. It can only list and toggle rows that already exist in MySQL.
- Approved leave is not a separate attendance status.
- There is no booked status. Interested is the closest stored status.

WHAT WAS CHECKED BEFORE THIS ZIP

PHP 8.3.36 parsed every PHP file. Requesting config.sample.php through PHP's built-in server returned 403 Forbidden and did not show the file. That server does not read .htaccess, so the Apache deny rule was not executed on Hostinger.

The schema was not imported into MySQL here. Login, setup, role checks, and /api/health were not run against a database. Do not treat those as passed until https://YOUR-DOMAIN/api/health returns mode mysql and the role checklist above has been clicked through.
