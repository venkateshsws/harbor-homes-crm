-- Yahoo CRM — MySQL 8 schema for Hostinger (PHP 8.1+ / PDO).
-- Import this file in phpMyAdmin after creating an empty database.
-- It does not create a login. Use setup.php once, then delete setup.php.

SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE TABLE companies (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(160) NOT NULL,
  code VARCHAR(32) NOT NULL,
  admin_name VARCHAR(160) NOT NULL,
  admin_email VARCHAR(190) NOT NULL,
  phone VARCHAR(40) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_companies_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  employee_code VARCHAR(32) NOT NULL,
  email VARCHAR(190) NOT NULL,
  full_name VARCHAR(160) NOT NULL,
  phone VARCHAR(40) NULL,
  role ENUM('super_admin','admin','team_lead','employee') NOT NULL,
  company_id INT UNSIGNED NULL,
  team_id INT UNSIGNED NULL,
  specialization VARCHAR(120) NULL,
  assignment_weight INT UNSIGNED NOT NULL DEFAULT 1,
  max_open_leads INT UNSIGNED NOT NULL DEFAULT 50,
  is_assignment_eligible TINYINT(1) NOT NULL DEFAULT 1,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  last_login_at DATETIME NULL,
  timezone VARCHAR(64) NOT NULL DEFAULT 'Asia/Kolkata',
  password_hash VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  UNIQUE KEY uq_users_code (employee_code),
  KEY idx_users_company_role (company_id, role),
  KEY idx_users_team (team_id),
  CONSTRAINT fk_users_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE teams (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  name VARCHAR(160) NOT NULL,
  description VARCHAR(500) NOT NULL DEFAULT '',
  team_lead_id INT UNSIGNED NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_teams_company (company_id),
  CONSTRAINT fk_teams_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE users
  ADD CONSTRAINT fk_users_team FOREIGN KEY (team_id) REFERENCES teams (id);

CREATE TABLE sessions (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  token_hash CHAR(64) NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  csrf_token VARCHAR(80) NOT NULL,
  expires_at DATETIME NOT NULL,
  ip VARCHAR(64) NULL,
  user_agent VARCHAR(300) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sessions_token (token_hash),
  KEY idx_sessions_user (user_id),
  KEY idx_sessions_expires (expires_at),
  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE leads (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  lead_code VARCHAR(32) NOT NULL,
  full_name VARCHAR(160) NOT NULL,
  mobile VARCHAR(32) NOT NULL,
  email VARCHAR(190) NOT NULL DEFAULT '',
  city VARCHAR(120) NOT NULL DEFAULT '',
  location VARCHAR(160) NOT NULL DEFAULT '',
  property_type ENUM('apartment','villa','plot','commercial','other') NOT NULL DEFAULT 'apartment',
  budget_min DECIMAL(14,2) NULL,
  budget_max DECIMAL(14,2) NULL,
  preferred_configuration VARCHAR(40) NOT NULL DEFAULT '2 BHK',
  source_id TINYINT UNSIGNED NOT NULL DEFAULT 1,
  priority ENUM('urgent','high','medium','low') NOT NULL DEFAULT 'medium',
  requirements TEXT NULL,
  consent_whatsapp TINYINT(1) NOT NULL DEFAULT 0,
  status_id TINYINT UNSIGNED NOT NULL DEFAULT 1,
  owner_id INT UNSIGNED NULL,
  created_by INT UNSIGNED NOT NULL,
  next_follow_up_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_leads_code (lead_code),
  KEY idx_leads_company_created (company_id, created_at),
  KEY idx_leads_company_owner (company_id, owner_id),
  KEY idx_leads_company_mobile (company_id, mobile),
  CONSTRAINT fk_leads_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_leads_owner FOREIGN KEY (owner_id) REFERENCES users (id),
  CONSTRAINT fk_leads_creator FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE lead_notes (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  lead_id INT UNSIGNED NOT NULL,
  author_id INT UNSIGNED NOT NULL,
  note TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_notes_lead (lead_id, created_at),
  CONSTRAINT fk_notes_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE,
  CONSTRAINT fk_notes_author FOREIGN KEY (author_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE lead_assignments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  lead_id INT UNSIGNED NOT NULL,
  from_user_id INT UNSIGNED NULL,
  to_user_id INT UNSIGNED NULL,
  assigned_by INT UNSIGNED NOT NULL,
  method VARCHAR(32) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_assign_lead (lead_id, created_at),
  CONSTRAINT fk_assign_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE lead_calls (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  lead_id INT UNSIGNED NOT NULL,
  employee_id INT UNSIGNED NOT NULL,
  started_at DATETIME NOT NULL,
  ended_at DATETIME NULL,
  duration_seconds INT UNSIGNED NOT NULL DEFAULT 0,
  gap_before_seconds INT UNSIGNED NOT NULL DEFAULT 0,
  outcome ENUM('answered','interested','callback_requested','no_answer','busy','switched_off','not_interested','invalid_number','other') NOT NULL DEFAULT 'other',
  notes TEXT NULL,
  status ENUM('in_progress','completed','missed') NOT NULL DEFAULT 'completed',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_calls_employee (company_id, employee_id, started_at),
  KEY idx_calls_lead (company_id, lead_id, started_at),
  CONSTRAINT fk_calls_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_calls_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE,
  CONSTRAINT fk_calls_employee FOREIGN KEY (employee_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE follow_ups (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  lead_id INT UNSIGNED NOT NULL,
  employee_id INT UNSIGNED NOT NULL,
  created_by INT UNSIGNED NOT NULL,
  title VARCHAR(160) NOT NULL,
  task_type ENUM('call','whatsapp','email','meeting','site_visit','other') NOT NULL DEFAULT 'call',
  priority ENUM('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  due_at DATETIME NOT NULL,
  status ENUM('pending','completed','cancelled') NOT NULL DEFAULT 'pending',
  notes TEXT NULL,
  completed_at DATETIME NULL,
  escalated_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_followups_employee (company_id, employee_id, due_at),
  KEY idx_followups_lead (company_id, lead_id, due_at),
  CONSTRAINT fk_followups_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_followups_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE,
  CONSTRAINT fk_followups_employee FOREIGN KEY (employee_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE site_visits (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  lead_id INT UNSIGNED NOT NULL,
  employee_id INT UNSIGNED NOT NULL,
  created_by INT UNSIGNED NOT NULL,
  property_id INT UNSIGNED NULL,
  property_name VARCHAR(160) NOT NULL DEFAULT '',
  scheduled_at DATETIME NOT NULL,
  status ENUM('scheduled','completed','cancelled','rescheduled','no_show') NOT NULL DEFAULT 'scheduled',
  notes TEXT NULL,
  feedback TEXT NULL,
  completed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_visits_employee (company_id, employee_id, scheduled_at),
  KEY idx_visits_lead (company_id, lead_id, scheduled_at),
  CONSTRAINT fk_visits_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_visits_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE,
  CONSTRAINT fk_visits_employee FOREIGN KEY (employee_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE attendance (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  company_id INT UNSIGNED NULL,
  employee_code VARCHAR(32) NOT NULL,
  full_name VARCHAR(160) NOT NULL,
  work_date DATE NOT NULL,
  timezone VARCHAR(64) NOT NULL DEFAULT 'Asia/Kolkata',
  login_at DATETIME NOT NULL,
  logout_at DATETIME NULL,
  sessions_json JSON NOT NULL,
  status ENUM('present','checked_out') NOT NULL DEFAULT 'present',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_attendance_user_day (user_id, work_date),
  KEY idx_attendance_company_day (company_id, work_date),
  CONSTRAINT fk_attendance_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE properties (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  name VARCHAR(160) NOT NULL,
  property_type ENUM('apartment','villa','plot','commercial','other') NOT NULL DEFAULT 'apartment',
  city VARCHAR(120) NOT NULL DEFAULT '',
  location VARCHAR(160) NOT NULL DEFAULT '',
  price_min DECIMAL(14,2) NULL,
  price_max DECIMAL(14,2) NULL,
  configuration VARCHAR(40) NOT NULL DEFAULT '2 BHK',
  status VARCHAR(32) NOT NULL DEFAULT 'available',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_properties_company (company_id),
  CONSTRAINT fk_properties_company FOREIGN KEY (company_id) REFERENCES companies (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE notifications (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(160) NOT NULL,
  body VARCHAR(500) NOT NULL DEFAULT '',
  link_path VARCHAR(190) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_notifications_user (user_id, is_read, created_at),
  CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE company_settings (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  setting_key VARCHAR(64) NOT NULL,
  value_json JSON NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_settings_company_key (company_id, setting_key),
  CONSTRAINT fk_settings_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE assignment_rules (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  name VARCHAR(160) NOT NULL,
  method VARCHAR(32) NOT NULL,
  team_id INT UNSIGNED NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_rules_company (company_id),
  CONSTRAINT fk_rules_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE assignment_queues (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  queue_key VARCHAR(64) NOT NULL,
  method VARCHAR(32) NOT NULL DEFAULT 'round_robin',
  last_user_id INT UNSIGNED NULL,
  is_paused TINYINT(1) NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_queue_company_key (company_id, queue_key),
  CONSTRAINT fk_queues_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE nurturing_sequences (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NOT NULL,
  name VARCHAR(160) NOT NULL,
  objective VARCHAR(500) NOT NULL DEFAULT '',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_nurture_company (company_id),
  CONSTRAINT fk_nurture_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE nurturing_steps (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sequence_id INT UNSIGNED NOT NULL,
  step_order INT UNSIGNED NOT NULL,
  action_type VARCHAR(40) NOT NULL,
  delay_hours INT UNSIGNED NOT NULL DEFAULT 0,
  task_title VARCHAR(160) NOT NULL DEFAULT '',
  PRIMARY KEY (id),
  KEY idx_nurture_steps (sequence_id, step_order),
  CONSTRAINT fk_nurture_steps FOREIGN KEY (sequence_id) REFERENCES nurturing_sequences (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE drip_campaigns (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  company_id INT UNSIGNED NULL,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(1000) NOT NULL DEFAULT '',
  trigger_type ENUM('manual','new_lead','status_change') NOT NULL DEFAULT 'manual',
  trigger_status_id TINYINT UNSIGNED NULL,
  steps_json JSON NOT NULL,
  status ENUM('draft','active','paused','archived') NOT NULL DEFAULT 'draft',
  created_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_campaigns_company (company_id, status),
  CONSTRAINT fk_campaigns_company FOREIGN KEY (company_id) REFERENCES companies (id),
  CONSTRAINT fk_campaigns_user FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE drip_enrollments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  campaign_id INT UNSIGNED NOT NULL,
  lead_id INT UNSIGNED NOT NULL,
  company_id INT UNSIGNED NULL,
  current_step INT UNSIGNED NOT NULL DEFAULT 1,
  status ENUM('active','paused','completed','stopped','failed') NOT NULL DEFAULT 'active',
  next_message_at DATETIME NULL,
  enrolled_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME NULL,
  stopped_reason VARCHAR(500) NOT NULL DEFAULT '',
  enrolled_by INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_enrollment (campaign_id, lead_id),
  KEY idx_enrollment_due (status, next_message_at),
  CONSTRAINT fk_enroll_campaign FOREIGN KEY (campaign_id) REFERENCES drip_campaigns (id) ON DELETE CASCADE,
  CONSTRAINT fk_enroll_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE,
  CONSTRAINT fk_enroll_user FOREIGN KEY (enrolled_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE drip_message_logs (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  campaign_id INT UNSIGNED NOT NULL,
  enrollment_id INT UNSIGNED NOT NULL,
  lead_id INT UNSIGNED NOT NULL,
  company_id INT UNSIGNED NULL,
  step_number INT UNSIGNED NOT NULL,
  recipient_phone VARCHAR(32) NOT NULL,
  template_name VARCHAR(120) NOT NULL,
  status ENUM('queued','processing','sent','delivered','read','failed','skipped') NOT NULL DEFAULT 'skipped',
  provider_message_id VARCHAR(120) NULL,
  attempt_count INT UNSIGNED NOT NULL DEFAULT 0,
  last_error VARCHAR(500) NOT NULL DEFAULT '',
  scheduled_at DATETIME NOT NULL,
  sent_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_message_step (enrollment_id, step_number),
  CONSTRAINT fk_msg_enrollment FOREIGN KEY (enrollment_id) REFERENCES drip_enrollments (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE audit_logs (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  actor_id INT UNSIGNED NULL,
  actor_name VARCHAR(160) NULL,
  action VARCHAR(80) NOT NULL,
  entity_type VARCHAR(40) NOT NULL,
  entity_id VARCHAR(32) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE attendance
  ADD CONSTRAINT fk_attendance_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE SET NULL;

ALTER TABLE site_visits
  ADD CONSTRAINT fk_visits_property FOREIGN KEY (property_id) REFERENCES properties (id) ON DELETE SET NULL;

ALTER TABLE assignment_rules
  ADD CONSTRAINT fk_rules_team FOREIGN KEY (team_id) REFERENCES teams (id) ON DELETE SET NULL;

ALTER TABLE assignment_queues
  ADD CONSTRAINT fk_queues_last_user FOREIGN KEY (last_user_id) REFERENCES users (id) ON DELETE SET NULL;

ALTER TABLE drip_enrollments
  ADD CONSTRAINT fk_enroll_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE SET NULL;

ALTER TABLE drip_message_logs
  ADD CONSTRAINT fk_msg_campaign FOREIGN KEY (campaign_id) REFERENCES drip_campaigns (id) ON DELETE CASCADE,
  ADD CONSTRAINT fk_msg_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE,
  ADD CONSTRAINT fk_msg_company FOREIGN KEY (company_id) REFERENCES companies (id) ON DELETE SET NULL;

ALTER TABLE audit_logs
  ADD CONSTRAINT fk_audit_actor FOREIGN KEY (actor_id) REFERENCES users (id) ON DELETE SET NULL;
