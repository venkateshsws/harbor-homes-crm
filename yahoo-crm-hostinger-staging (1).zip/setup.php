<?php

ini_set('display_errors', '0');
date_default_timezone_set('UTC');
define('APP_ROOT', __DIR__);

require __DIR__ . '/api/lib/http.php';
require __DIR__ . '/api/lib/db.php';
require __DIR__ . '/api/lib/auth.php';

function setup_key()
{
    $config = cfg();
    $key = isset($config['setup_key']) ? (string) $config['setup_key'] : '';
    if (strlen($key) < 16) {
        throw new HttpError('Set setup_key in config.php to a random string of at least 16 characters before opening setup.', 500);
    }
    return $key;
}

function setup_page($error = '')
{
    header('Content-Type: text/html; charset=utf-8');
    $message = $error !== '' ? '<p style="color:#9f1239">' . htmlspecialchars($error, ENT_QUOTES, 'UTF-8') . '</p>' : '';
    echo '<!doctype html><html><head><meta charset="utf-8"><title>Yahoo CRM setup</title></head><body style="font-family:sans-serif;max-width:32rem;margin:2rem auto">';
    echo '<h1>Create the first super admin</h1>';
    echo '<p>This page works only while the users table is empty. Enter the setup key from config.php. After the account is created, this file removes itself.</p>';
    echo $message;
    echo '<form method="post"><p><label>Setup key<br><input name="setup_key" type="password" required></label></p>';
    echo '<p><label>Full name<br><input name="full_name" required></label></p>';
    echo '<p><label>Email<br><input name="email" type="email" required></label></p>';
    echo '<p><label>Employee code<br><input name="employee_code" required></label></p>';
    echo '<p><label>Password (at least 10 characters)<br><input name="password" type="password" required minlength="10"></label></p>';
    echo '<button type="submit">Create super admin</button></form></body></html>';
    exit;
}

try {
    $count = (int) db_one('SELECT COUNT(*) AS c FROM users')['c'];
} catch (Throwable $error) {
    setup_page('Database connection failed. Import database/schema.sql and copy config.sample.php to config.php first.');
}

if ($count > 0) {
    @unlink(__FILE__);
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Setup is closed because a user already exists. This file can no longer create an account.\n";
    exit;
}

try {
    $expectedKey = setup_key();
} catch (Throwable $error) {
    setup_page($error->getMessage());
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    setup_page();
}

try {
    rate_limit('setup', 8, 15 * 60, 'Too many setup attempts. Try again in 15 minutes.');
} catch (HttpError $error) {
    http_response_code($error->getCode() ?: 429);
    setup_page($error->getMessage());
}
$givenKey = (string) ($_POST['setup_key'] ?? '');
if (!hash_equals($expectedKey, $givenKey)) {
    setup_page('The setup key does not match config.php.');
}

$name = trim((string) ($_POST['full_name'] ?? ''));
$email = strtolower(trim((string) ($_POST['email'] ?? '')));
$code = strtoupper(trim((string) ($_POST['employee_code'] ?? '')));
$password = (string) ($_POST['password'] ?? '');
$problem = password_problem($password);
if ($name === '' || !email_ok($email) || $code === '' || $problem) {
    setup_page($problem ?: 'Enter a name, a valid email, an employee code, and a password of at least 10 characters.');
}

$pdo = db();
$lock = db_one("SELECT GET_LOCK('yahoo_crm_setup', 15) AS locked");
if ((int) ($lock['locked'] ?? 0) !== 1) {
    setup_page('Setup is busy. Wait a moment and try again.');
}

try {
    $pdo->beginTransaction();
    $count = (int) db_one('SELECT COUNT(*) AS c FROM users FOR UPDATE')['c'];
    if ($count > 0) {
        $pdo->rollBack();
        db_one("SELECT RELEASE_LOCK('yahoo_crm_setup')");
        @unlink(__FILE__);
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        echo "Setup is closed because a user already exists. This file can no longer create an account.\n";
        exit;
    }
    db_insert(
        'INSERT INTO users (employee_code, email, full_name, role, is_active, password_hash, timezone, created_at, updated_at)
         VALUES (?, ?, ?, \'super_admin\', 1, ?, \'Asia/Kolkata\', ?, ?)',
        [$code, $email, $name, hash_password($password), utc_now(), utc_now()]
    );
    $pdo->commit();
} catch (Throwable $error) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    db_one("SELECT RELEASE_LOCK('yahoo_crm_setup')");
    setup_page('The super admin could not be created. Check that the database import finished and that the email and employee code are unused.');
}
db_one("SELECT RELEASE_LOCK('yahoo_crm_setup')");
$removed = @unlink(__FILE__);

header('Content-Type: text/html; charset=utf-8');
echo '<!doctype html><html><head><meta charset="utf-8"><title>Yahoo CRM setup</title></head><body style="font-family:sans-serif;max-width:32rem;margin:2rem auto">';
echo '<h1>Super admin created</h1>';
if ($removed) {
    echo '<p>setup.php has been removed. Sign in at the site home page. Opening /setup.php again should show the CRM, not this form.</p>';
} else {
    echo '<p>The account was created, but setup.php could not delete itself. Delete setup.php from public_html now. It will refuse to create another account.</p>';
}
echo '</body></html>';
