<?php

function company_code()
{
    return 'YCR-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6));
}

function format_company($company, $employees = 0, $leads = 0)
{
    $active = (bool) $company['is_active'];
    return [
        'id' => (string) $company['id'],
        'name' => $company['name'],
        'code' => $company['code'],
        'admin_name' => $company['admin_name'] ?? '',
        'admin_email' => $company['admin_email'] ?? '',
        'phone' => $company['phone'] ?? '',
        'employees' => (int) $employees,
        'employee_count' => (int) $employees,
        'leads' => (int) $leads,
        'lead_count' => (int) $leads,
        'is_active' => $active,
        'status' => $active ? 'Active' : 'Inactive',
        'created_at' => iso_dt($company['created_at'] ?? null),
    ];
}

function handle_companies_list()
{
    require_role('super_admin');
    $rows = db_all('SELECT * FROM companies ORDER BY created_at DESC');
    $data = [];
    foreach ($rows as $company) {
        $employees = (int) db_one(
            "SELECT COUNT(*) AS c FROM users WHERE company_id = ? AND role = 'employee'",
            [(int) $company['id']]
        )['c'];
        $leads = (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE company_id = ?', [(int) $company['id']])['c'];
        $data[] = format_company($company, $employees, $leads);
    }
    json_ok(['companies' => $data]);
}

function handle_company_create()
{
    require_role('super_admin');
    $body = request_data();
    $name = trim((string) ($body['name'] ?? ''));
    $adminName = trim((string) ($body['admin_name'] ?? ''));
    $adminEmail = strtolower(trim((string) ($body['admin_email'] ?? '')));
    $phone = trim((string) ($body['phone'] ?? ''));
    if ($name === '' || $adminName === '' || !email_ok($adminEmail)) {
        throw new HttpError('Enter a company name, admin name, and valid admin email.', 400);
    }
    $code = company_code();
    try {
        $id = db_insert(
            'INSERT INTO companies (name, code, admin_name, admin_email, phone, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, ?, ?)',
            [$name, $code, $adminName, $adminEmail, $phone !== '' ? $phone : null, utc_now(), utc_now()]
        );
    } catch (Throwable $error) {
        if (is_duplicate($error)) {
            throw new HttpError('A company with this unique value already exists.', 409);
        }
        throw $error;
    }
    db_insert(
        'INSERT INTO assignment_rules (company_id, name, method, is_active, sort_order) VALUES (?, ?, ?, 1, 1)',
        [$id, 'Default round robin', 'round_robin']
    );
    db_insert(
        'INSERT INTO assignment_queues (company_id, queue_key, method, is_paused) VALUES (?, ?, ?, 0)',
        [$id, 'default', 'round_robin']
    );
    $company = db_one('SELECT * FROM companies WHERE id = ?', [$id]);
    audit_write('create_company', 'company', $id);
    json_out([
        'success' => true,
        'data' => ['company' => format_company($company, 0, 0)],
    ], 201);
}

function handle_company_update($id)
{
    require_role('super_admin');
    $companyId = int_id($id, 'company ID');
    $company = db_one('SELECT * FROM companies WHERE id = ?', [$companyId]);
    if (!$company) {
        throw new HttpError('Company not found.', 404);
    }
    $body = request_data();
    $updates = [];
    $params = [];
    if (array_key_exists('name', $body)) {
        $name = trim((string) $body['name']);
        if ($name === '') {
            throw new HttpError('Company name is required.', 400);
        }
        $updates[] = 'name = ?';
        $params[] = $name;
    }
    if (array_key_exists('admin_name', $body)) {
        $adminName = trim((string) $body['admin_name']);
        if ($adminName === '') {
            throw new HttpError('Admin name is required.', 400);
        }
        $updates[] = 'admin_name = ?';
        $params[] = $adminName;
    }
    if (array_key_exists('admin_email', $body)) {
        $email = strtolower(trim((string) $body['admin_email']));
        if (!email_ok($email)) {
            throw new HttpError('Enter a valid admin email.', 400);
        }
        $updates[] = 'admin_email = ?';
        $params[] = $email;
    }
    if (array_key_exists('phone', $body)) {
        $phone = trim((string) $body['phone']);
        $updates[] = 'phone = ?';
        $params[] = $phone !== '' ? $phone : null;
    }
    $admin = db_one("SELECT * FROM users WHERE company_id = ? AND role = 'admin' ORDER BY id ASC LIMIT 1", [$companyId]);
    if (array_key_exists('admin_email', $body)) {
        $email = strtolower(trim((string) $body['admin_email']));
        $existing = db_one('SELECT id FROM users WHERE email = ? AND id <> ?', [$email, $admin['id'] ?? 0]);
        if ($existing) {
            throw new HttpError('This email is already used by another user account.', 409);
        }
    }
    if ($admin) {
        $adminSets = [];
        $adminParams = [];
        if (array_key_exists('admin_name', $body)) {
            $adminSets[] = 'full_name = ?';
            $adminParams[] = trim((string) $body['admin_name']);
        }
        if (array_key_exists('admin_email', $body)) {
            $adminSets[] = 'email = ?';
            $adminParams[] = strtolower(trim((string) $body['admin_email']));
        }
        if ($adminSets) {
            $adminParams[] = (int) $admin['id'];
            db_exec('UPDATE users SET ' . implode(', ', $adminSets) . ' WHERE id = ?', $adminParams);
        }
    }
    if ($updates) {
        $params[] = $companyId;
        db_exec('UPDATE companies SET ' . implode(', ', $updates) . ' WHERE id = ?', $params);
    }
    $company = db_one('SELECT * FROM companies WHERE id = ?', [$companyId]);
    audit_write('update_company', 'company', $companyId);
    json_out([
        'success' => true,
        'message' => 'Company details updated successfully.',
        'data' => [
            'company' => format_company($company),
            'admin_account_updated' => (bool) $admin,
        ],
    ]);
}

function handle_company_status($id)
{
    require_role('super_admin');
    $companyId = int_id($id, 'company ID');
    $body = request_data();
    if (!array_key_exists('is_active', $body) || !is_bool($body['is_active'])) {
        throw new HttpError('is_active must be true or false.', 400);
    }
    $company = db_one('SELECT * FROM companies WHERE id = ?', [$companyId]);
    if (!$company) {
        throw new HttpError('Company not found.', 404);
    }
    db_exec('UPDATE companies SET is_active = ? WHERE id = ?', [$body['is_active'] ? 1 : 0, $companyId]);
    audit_write($body['is_active'] ? 'activate_company' : 'deactivate_company', 'company', $companyId);
    json_ok([
        'id' => (string) $companyId,
        'name' => $company['name'],
        'is_active' => (bool) $body['is_active'],
        'status' => $body['is_active'] ? 'Active' : 'Inactive',
    ]);
}

function format_admin($user, $company)
{
    $employees = 0;
    if ($company) {
        $employees = (int) db_one(
            "SELECT COUNT(*) AS c FROM users WHERE company_id = ? AND role = 'employee'",
            [(int) $company['id']]
        )['c'];
    }
    return [
        'id' => (string) $user['id'],
        'employee_code' => $user['employee_code'],
        'full_name' => $user['full_name'],
        'name' => $user['full_name'],
        'email' => $user['email'],
        'phone' => $user['phone'] ?? '',
        'role' => $user['role'],
        'company_id' => $company ? (string) $company['id'] : null,
        'company_name' => $company['name'] ?? '',
        'company_code' => $company['code'] ?? '',
        'is_active' => (bool) $user['is_active'],
        'status' => $user['is_active'] ? 'Active' : 'Inactive',
        'employees' => $employees,
        'created_at' => iso_dt($user['created_at'] ?? null),
    ];
}

function handle_company_admins_list()
{
    require_role('super_admin');
    $rows = db_all("SELECT * FROM users WHERE role = 'admin' ORDER BY created_at DESC");
    $admins = [];
    foreach ($rows as $user) {
        $company = $user['company_id'] ? db_one('SELECT * FROM companies WHERE id = ?', [(int) $user['company_id']]) : null;
        $admins[] = format_admin($user, $company);
    }
    json_out(['success' => true, 'admins' => $admins, 'data' => $admins]);
}

function handle_company_admin_create()
{
    require_role('super_admin');
    $body = request_data();
    $name = trim((string) ($body['full_name'] ?? ''));
    $email = strtolower(trim((string) ($body['email'] ?? '')));
    $phone = trim((string) ($body['phone'] ?? ''));
    $password = (string) ($body['password'] ?? '');
    $companyId = $body['company_id'] ?? null;
    if ($name === '' || $email === '' || $password === '' || !$companyId) {
        throw new HttpError('Name, email, password and company are required.', 400);
    }
    if (!email_ok($email)) {
        throw new HttpError('Enter a valid email address.', 400);
    }
    if (strlen($password) < 8) {
        throw new HttpError('Password must contain at least 8 characters.', 400);
    }
    $companyId = int_id($companyId, 'company ID');
    $company = db_one('SELECT * FROM companies WHERE id = ?', [$companyId]);
    if (!$company) {
        throw new HttpError('Company not found.', 404);
    }
    if (!(int) $company['is_active']) {
        throw new HttpError('Cannot assign an admin to an inactive company.', 400);
    }
    if (db_one("SELECT id FROM users WHERE company_id = ? AND role = 'admin'", [$companyId])) {
        throw new HttpError('This company already has a Company Admin account.', 409);
    }
    if (db_one('SELECT id FROM users WHERE email = ?', [$email])) {
        throw new HttpError('An account with this email already exists.', 409);
    }
    $code = '';
    for ($i = 0; $i < 8; $i++) {
        $code = 'ADM' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 5));
        if (!db_one('SELECT id FROM users WHERE employee_code = ?', [$code])) {
            break;
        }
    }
    $id = db_insert(
        'INSERT INTO users (employee_code, email, full_name, phone, role, company_id, is_assignment_eligible, is_active, password_hash, created_at, updated_at)
         VALUES (?, ?, ?, ?, \'admin\', ?, 0, 1, ?, ?, ?)',
        [$code, $email, $name, $phone !== '' ? $phone : null, $companyId, hash_password($password), utc_now(), utc_now()]
    );
    db_exec('UPDATE companies SET admin_name = ?, admin_email = ? WHERE id = ?', [$name, $email, $companyId]);
    $user = db_one('SELECT * FROM users WHERE id = ?', [$id]);
    $company = db_one('SELECT * FROM companies WHERE id = ?', [$companyId]);
    audit_write('create_company_admin', 'user', $id);
    json_out([
        'success' => true,
        'message' => 'Company Admin created successfully.',
        'admin' => format_admin($user, $company),
    ], 201);
}

function handle_company_admin_status($id)
{
    require_role('super_admin');
    $userId = int_id($id, 'user ID');
    $body = request_data();
    if (!array_key_exists('is_active', $body) || !is_bool($body['is_active'])) {
        throw new HttpError('is_active must be true or false.', 400);
    }
    $user = db_one("SELECT * FROM users WHERE id = ? AND role = 'admin'", [$userId]);
    if (!$user) {
        throw new HttpError('Company Admin not found.', 404);
    }
    db_exec('UPDATE users SET is_active = ? WHERE id = ?', [$body['is_active'] ? 1 : 0, $userId]);
    if (!$body['is_active']) {
        db_exec('DELETE FROM sessions WHERE user_id = ?', [$userId]);
    }
    audit_write($body['is_active'] ? 'activate_user' : 'deactivate_user', 'user', $userId);
    json_ok(['id' => (string) $userId, 'is_active' => (bool) $body['is_active']]);
}

function handle_company_admin_assign($id)
{
    require_role('super_admin');
    $userId = int_id($id, 'user ID');
    $body = request_data();
    $companyId = int_id($body['company_id'] ?? null, 'company ID');
    $user = db_one("SELECT * FROM users WHERE id = ? AND role = 'admin'", [$userId]);
    if (!$user) {
        throw new HttpError('Company Admin not found.', 404);
    }
    $company = db_one('SELECT * FROM companies WHERE id = ?', [$companyId]);
    if (!$company) {
        throw new HttpError('Company not found.', 404);
    }
    $other = db_one("SELECT id FROM users WHERE company_id = ? AND role = 'admin' AND id <> ?", [$companyId, $userId]);
    if ($other) {
        throw new HttpError('This company already has a Company Admin account.', 409);
    }
    db_exec('UPDATE users SET company_id = ? WHERE id = ?', [$companyId, $userId]);
    db_exec('UPDATE companies SET admin_name = ?, admin_email = ? WHERE id = ?', [$user['full_name'], $user['email'], $companyId]);
    audit_write('assign_company_admin', 'user', $userId);
    $user['company_id'] = $companyId;
    json_ok(format_admin($user, $company));
}
