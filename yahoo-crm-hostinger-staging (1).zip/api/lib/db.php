<?php

function cfg()
{
    static $config;
    if ($config !== null) {
        return $config;
    }
    $file = APP_ROOT . '/config.php';
    if (!is_file($file)) {
        throw new HttpError('Copy config.sample.php to config.php and set the MySQL database.', 500);
    }
    $loaded = require $file;
    if (!is_array($loaded) || empty($loaded['db_name']) || empty($loaded['db_user'])) {
        throw new HttpError('Database settings in config.php are incomplete.', 500);
    }
    $config = $loaded;
    return $config;
}

function db()
{
    static $pdo;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $config = cfg();
    $dsn = 'mysql:host=' . $config['db_host'] . ';dbname=' . $config['db_name'] . ';charset=utf8mb4';
    $pdo = new PDO($dsn, $config['db_user'], $config['db_pass'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec("SET time_zone = '+00:00'");
    return $pdo;
}

function db_all($sql, $params = [])
{
    $stmt = db()->prepare($sql);
    $stmt->execute(array_values($params));
    return $stmt->fetchAll();
}

function db_one($sql, $params = [])
{
    $stmt = db()->prepare($sql);
    $stmt->execute(array_values($params));
    $row = $stmt->fetch();
    return $row === false ? null : $row;
}

function db_exec($sql, $params = [])
{
    $stmt = db()->prepare($sql);
    $stmt->execute(array_values($params));
    return $stmt->rowCount();
}

function db_insert($sql, $params = [])
{
    db_exec($sql, $params);
    return (int) db()->lastInsertId();
}

function is_duplicate(Throwable $error)
{
    return $error instanceof PDOException && ($error->errorInfo[1] ?? null) === 1062;
}
