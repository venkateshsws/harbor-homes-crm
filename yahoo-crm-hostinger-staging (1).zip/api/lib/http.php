<?php

class HttpError extends Exception
{
    public function __construct($message, $status = 400)
    {
        parent::__construct($message, (int) $status);
    }
}

function json_out($data, $status = 200)
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function json_ok($data = [], $status = 200, $extra = [])
{
    json_out(array_merge(['success' => true], $extra, ['data' => $data]), $status);
}

function json_error($message, $status = 400, $extra = [])
{
    json_out(array_merge(['success' => false, 'error' => $message], $extra), $status);
}

function api_path()
{
    $candidates = [];
    if (!empty($_SERVER['THE_REQUEST']) && preg_match('#\s(/[^?\s]*)#', $_SERVER['THE_REQUEST'], $match)) {
        $candidates[] = $match[1];
    }
    if (!empty($_SERVER['REDIRECT_URL'])) {
        $candidates[] = $_SERVER['REDIRECT_URL'];
    }
    if (!empty($_SERVER['REQUEST_URI'])) {
        $parsed = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        if (is_string($parsed)) {
            $candidates[] = $parsed;
        }
    }
    foreach ($candidates as $path) {
        if ($path === '' || strpos($path, '/api/index.php') !== false) {
            continue;
        }
        $pos = strpos($path, '/api');
        if ($pos === false) {
            continue;
        }
        $rest = substr($path, $pos + 4);
        $rest = '/' . trim($rest, '/');
        return $rest === '/' ? '/' : $rest;
    }
    return '/';
}

function request_data()
{
    $contentType = $_SERVER['CONTENT_TYPE'] ?? $_SERVER['HTTP_CONTENT_TYPE'] ?? '';
    if (stripos($contentType, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        if ($raw === false || $raw === '') {
            return [];
        }
        if (strlen($raw) > 1048576) {
            throw new HttpError('Request body is too large.', 413);
        }
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            throw new HttpError('Request body must be JSON.', 400);
        }
        return $data;
    }
    return is_array($_POST) ? $_POST : [];
}

function client_ip()
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    return is_string($ip) ? substr($ip, 0, 64) : '';
}

function rate_limit($bucket, $max, $window, $message)
{
    $dir = APP_ROOT . '/storage/ratelimit';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $file = $dir . '/' . hash('sha256', $bucket . '|' . client_ip()) . '.json';
    $handle = @fopen($file, 'c+');
    if (!$handle) {
        return;
    }
    flock($handle, LOCK_EX);
    $raw = stream_get_contents($handle);
    $hits = json_decode($raw ?: '[]', true);
    if (!is_array($hits)) {
        $hits = [];
    }
    $now = time();
    $fresh = [];
    foreach ($hits as $hit) {
        if (is_numeric($hit) && (int) $hit > $now - $window) {
            $fresh[] = (int) $hit;
        }
    }
    if (count($fresh) >= $max) {
        flock($handle, LOCK_UN);
        fclose($handle);
        throw new HttpError($message, 429);
    }
    $fresh[] = $now;
    ftruncate($handle, 0);
    rewind($handle);
    fwrite($handle, json_encode($fresh));
    fflush($handle);
    flock($handle, LOCK_UN);
    fclose($handle);
}

function utc_now()
{
    return gmdate('Y-m-d H:i:s');
}

function iso_dt($value)
{
    if ($value === null || $value === '') {
        return null;
    }
    $ts = strtotime((string) $value . (preg_match('/Z$|[+-]\d\d:?\d\d$/', (string) $value) ? '' : ' UTC'));
    if ($ts === false) {
        return (string) $value;
    }
    return gmdate('Y-m-d\TH:i:s\Z', $ts);
}

function sql_dt($value)
{
    if ($value === null || $value === '') {
        return null;
    }
    $ts = strtotime((string) $value);
    if ($ts === false) {
        throw new HttpError('Invalid date.', 400);
    }
    return gmdate('Y-m-d H:i:s', $ts);
}

function work_date($timezone = 'Asia/Kolkata')
{
    try {
        $zone = new DateTimeZone($timezone ?: 'Asia/Kolkata');
    } catch (Exception $e) {
        $zone = new DateTimeZone('Asia/Kolkata');
    }
    return (new DateTime('now', $zone))->format('Y-m-d');
}

function local_day_utc_bounds($date, $timezone = 'Asia/Kolkata')
{
    try {
        $zone = new DateTimeZone($timezone ?: 'Asia/Kolkata');
    } catch (Exception $e) {
        $zone = new DateTimeZone('Asia/Kolkata');
    }
    $start = new DateTime($date . ' 00:00:00', $zone);
    $end = clone $start;
    $end->modify('+1 day');
    $start->setTimezone(new DateTimeZone('UTC'));
    $end->setTimezone(new DateTimeZone('UTC'));
    return [$start->format('Y-m-d H:i:s'), $end->format('Y-m-d H:i:s')];
}

function int_id($value, $label = 'ID')
{
    if (!is_scalar($value) || !preg_match('/^\d+$/', (string) $value)) {
        throw new HttpError('Invalid ' . $label . '.', 400);
    }
    return (int) $value;
}

function email_ok($email)
{
    return is_string($email) && (bool) preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email);
}

function role_name($role)
{
    return [
        'super_admin' => 'Super Admin',
        'admin' => 'Company Admin',
        'team_lead' => 'Team Lead',
        'employee' => 'Employee',
    ][$role] ?? $role;
}

function lead_statuses()
{
    return [
        ['id' => 1, 'name' => 'New'],
        ['id' => 2, 'name' => 'Interested'],
        ['id' => 3, 'name' => 'Schedule for site visit'],
        ['id' => 4, 'name' => 'Not interested'],
        ['id' => 5, 'name' => 'Follow up'],
    ];
}

function lead_sources()
{
    return [
        ['id' => 1, 'name' => 'Website'],
        ['id' => 2, 'name' => 'Phone'],
        ['id' => 3, 'name' => 'WhatsApp'],
        ['id' => 4, 'name' => 'Referral'],
        ['id' => 5, 'name' => 'Other'],
    ];
}

function status_name($id)
{
    foreach (lead_statuses() as $status) {
        if ((int) $status['id'] === (int) $id) {
            return $status['name'];
        }
    }
    return 'New';
}

function audit_write($action, $entityType, $entityId)
{
    $user = current_user();
    db_exec(
        'INSERT INTO audit_logs (actor_id, actor_name, action, entity_type, entity_id, created_at) VALUES (?, ?, ?, ?, ?, ?)',
        [
            $user['id'] ?? null,
            $user['full_name'] ?? null,
            $action,
            $entityType,
            $entityId === null ? null : (string) $entityId,
            utc_now(),
        ]
    );
}

function notify_user($userId, $title, $body, $link = null)
{
    if (!$userId) {
        return;
    }
    db_exec(
        'INSERT INTO notifications (user_id, title, body, link_path, is_read, created_at) VALUES (?, ?, ?, ?, 0, ?)',
        [(int) $userId, $title, $body, $link, utc_now()]
    );
}
