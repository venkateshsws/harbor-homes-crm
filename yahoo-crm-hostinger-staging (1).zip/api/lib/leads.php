<?php

function lead_company_id($user)
{
    if ($user['role'] === 'super_admin') {
        return null;
    }
    if (empty($user['company_id'])) {
        throw new HttpError('Your account is not assigned to a valid company.', 403);
    }
    return (int) $user['company_id'];
}

function lead_select_sql()
{
    return 'SELECT l.*, o.full_name AS owner_name, c.name AS company_name, c.code AS company_code
            FROM leads l
            LEFT JOIN users o ON o.id = l.owner_id
            LEFT JOIN companies c ON c.id = l.company_id';
}

function serialize_lead($lead)
{
    return [
        'id' => (string) $lead['id'],
        'lead_code' => $lead['lead_code'],
        'full_name' => $lead['full_name'],
        'mobile' => $lead['mobile'],
        'email' => $lead['email'],
        'city' => $lead['city'],
        'location' => $lead['location'],
        'property_type' => $lead['property_type'],
        'budget_min' => $lead['budget_min'] !== null ? (float) $lead['budget_min'] : null,
        'budget_max' => $lead['budget_max'] !== null ? (float) $lead['budget_max'] : null,
        'preferred_configuration' => $lead['preferred_configuration'],
        'source_id' => (int) $lead['source_id'],
        'priority' => $lead['priority'],
        'requirements' => $lead['requirements'] ?? '',
        'consent_whatsapp' => (bool) $lead['consent_whatsapp'],
        'status_id' => (int) $lead['status_id'],
        'status_name' => status_name($lead['status_id']),
        'owner_name' => $lead['owner_name'] ?? null,
        'owner_id' => $lead['owner_id'] ? (string) $lead['owner_id'] : null,
        'company_id' => (string) $lead['company_id'],
        'company_name' => $lead['company_name'] ?? null,
        'company_code' => $lead['company_code'] ?? null,
        'next_follow_up_at' => iso_dt($lead['next_follow_up_at']),
        'created_at' => iso_dt($lead['created_at']),
        'is_terminal' => (int) $lead['status_id'] === 4 ? 1 : 0,
    ];
}

function visible_lead_sql($user, &$params)
{
    $params = [];
    if ($user['role'] === 'super_admin') {
        return '1 = 1';
    }
    $companyId = lead_company_id($user);
    if ($user['role'] === 'admin') {
        $params[] = $companyId;
        return 'l.company_id = ?';
    }
    if ($user['role'] === 'employee') {
        $params[] = $companyId;
        $params[] = (int) $user['id'];
        return 'l.company_id = ? AND l.owner_id = ?';
    }
    if ($user['role'] === 'team_lead') {
        if (empty($user['team_id'])) {
            return '1 = 0';
        }
        $members = db_all(
            "SELECT id FROM users WHERE company_id = ? AND team_id = ? AND role = 'employee' AND is_active = 1",
            [$companyId, (int) $user['team_id']]
        );
        $ids = array_map(function ($row) {
            return (int) $row['id'];
        }, $members);
        $ids[] = (int) $user['id'];
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $params[] = $companyId;
        foreach ($ids as $id) {
            $params[] = $id;
        }
        return "l.company_id = ? AND l.owner_id IN ($placeholders)";
    }
    throw new HttpError('You do not have permission to view leads.', 403);
}

function fetch_lead($id)
{
    return db_one(lead_select_sql() . ' WHERE l.id = ?', [(int) $id]);
}

function assert_lead_visible($user, $lead)
{
    if ($user['role'] === 'super_admin') {
        return;
    }
    if ((int) $lead['company_id'] !== (int) $user['company_id']) {
        throw new HttpError('Lead not found.', 404);
    }
    if ($user['role'] === 'employee' && (int) $lead['owner_id'] !== (int) $user['id']) {
        throw new HttpError('Lead not found.', 404);
    }
    if ($user['role'] === 'team_lead') {
        $params = [];
        $sql = visible_lead_sql($user, $params);
        $params[] = (int) $lead['id'];
        $row = db_one("SELECT l.id FROM leads l WHERE $sql AND l.id = ?", $params);
        if (!$row) {
            throw new HttpError('Lead not found.', 404);
        }
    }
}

function normalize_lead_input($data, $partial = false)
{
    $name = trim((string) ($data['full_name'] ?? ''));
    $mobile = trim((string) ($data['mobile'] ?? ''));
    if (!$partial && ($name === '' || $mobile === '')) {
        throw new HttpError('Full name and mobile are required.', 400);
    }
    $types = ['apartment', 'villa', 'plot', 'commercial', 'other'];
    $priorities = ['urgent', 'high', 'medium', 'low'];
    $type = (string) ($data['property_type'] ?? 'apartment');
    $priority = (string) ($data['priority'] ?? 'medium');
    if (!in_array($type, $types, true)) {
        $type = 'apartment';
    }
    if (!in_array($priority, $priorities, true)) {
        throw new HttpError('Invalid lead priority.', 400);
    }
    $statusId = (int) ($data['status_id'] ?? 1);
    if (!in_array($statusId, [1, 2, 3, 4, 5], true)) {
        throw new HttpError('Invalid lead status.', 400);
    }
    $budgetMin = ($data['budget_min'] ?? '') === '' || ($data['budget_min'] ?? null) === null ? null : (float) $data['budget_min'];
    $budgetMax = ($data['budget_max'] ?? '') === '' || ($data['budget_max'] ?? null) === null ? null : (float) $data['budget_max'];
    return [
        'full_name' => $name,
        'mobile' => $mobile,
        'email' => strtolower(trim((string) ($data['email'] ?? ''))),
        'city' => trim((string) ($data['city'] ?? '')),
        'location' => trim((string) ($data['location'] ?? '')),
        'property_type' => $type,
        'budget_min' => $budgetMin,
        'budget_max' => $budgetMax,
        'preferred_configuration' => trim((string) ($data['preferred_configuration'] ?? '2 BHK')) ?: '2 BHK',
        'source_id' => (int) ($data['source_id'] ?? 1) ?: 1,
        'priority' => $priority,
        'requirements' => trim((string) ($data['requirements'] ?? '')),
        'consent_whatsapp' => !empty($data['consent_whatsapp']) ? 1 : 0,
        'status_id' => $statusId,
    ];
}

function eligible_assignees($companyId, $teamId = null)
{
    $sql = "SELECT * FROM users WHERE company_id = ? AND is_active = 1 AND is_assignment_eligible = 1 AND role IN ('employee','team_lead')";
    $params = [$companyId];
    if ($teamId) {
        $sql .= ' AND team_id = ?';
        $params[] = $teamId;
    }
    $sql .= ' ORDER BY full_name ASC';
    return db_all($sql, $params);
}

function pick_assignee($companyId, $method, $teamId = null)
{
    $people = eligible_assignees($companyId, $teamId);
    if ($teamId) {
        $people = array_values(array_filter($people, function ($person) use ($teamId) {
            return (int) $person['team_id'] === (int) $teamId || $person['role'] === 'team_lead';
        }));
    }
    if (!$people) {
        throw new HttpError('No eligible employee is available for assignment.', 409);
    }
    if ($method === 'workload') {
        usort($people, function ($a, $b) {
            $ca = (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE owner_id = ? AND status_id <> 4', [(int) $a['id']])['c'];
            $cb = (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE owner_id = ? AND status_id <> 4', [(int) $b['id']])['c'];
            return $ca <=> $cb;
        });
        return $people[0];
    }
    if ($method === 'priority') {
        usort($people, function ($a, $b) {
            return ((int) $b['assignment_weight']) <=> ((int) $a['assignment_weight']);
        });
        return $people[0];
    }
    $queue = db_one('SELECT * FROM assignment_queues WHERE company_id = ? AND queue_key = ?', [$companyId, 'default']);
    if ($queue && (int) $queue['is_paused']) {
        throw new HttpError('The assignment queue is paused.', 409);
    }
    $last = $queue['last_user_id'] ?? null;
    $index = 0;
    if ($last) {
        foreach ($people as $i => $person) {
            if ((int) $person['id'] === (int) $last) {
                $index = ($i + 1) % count($people);
                break;
            }
        }
    }
    $chosen = $people[$index];
    if ($queue) {
        db_exec('UPDATE assignment_queues SET last_user_id = ? WHERE id = ?', [(int) $chosen['id'], (int) $queue['id']]);
    }
    return $chosen;
}

function assign_lead_to($lead, $assignee, $actor, $method)
{
    $open = (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE owner_id = ? AND status_id <> 4', [(int) $assignee['id']])['c'];
    if ($open >= (int) $assignee['max_open_leads']) {
        throw new HttpError($assignee['full_name'] . ' has reached the open lead limit.', 409);
    }
    db_exec('UPDATE leads SET owner_id = ? WHERE id = ?', [(int) $assignee['id'], (int) $lead['id']]);
    db_insert(
        'INSERT INTO lead_assignments (lead_id, from_user_id, to_user_id, assigned_by, method, created_at) VALUES (?, ?, ?, ?, ?, ?)',
        [(int) $lead['id'], $lead['owner_id'], (int) $assignee['id'], (int) $actor['id'], $method, utc_now()]
    );
    notify_user((int) $assignee['id'], 'Lead assigned', $lead['full_name'] . ' was assigned to you.', '/leads/' . $lead['id']);
    audit_write('assign_lead', 'lead', $lead['id']);
}

function handle_leads_meta()
{
    require_user();
    json_ok(['statuses' => lead_statuses(), 'sources' => lead_sources()]);
}

function handle_leads_list()
{
    $user = require_user();
    $params = [];
    if (($_GET['unassigned'] ?? '') === '1') {
        if (!in_array($user['role'], ['admin', 'team_lead'], true)) {
            throw new HttpError('Only Admins and Team Leads can view the assignment queue.', 403);
        }
        $companyId = lead_company_id($user);
        $sql = 'l.company_id = ? AND l.owner_id IS NULL';
        $params = [$companyId];
    } else {
        $sql = visible_lead_sql($user, $params);
    }
    if (!empty($_GET['status_id'])) {
        $statusId = (int) $_GET['status_id'];
        if (!in_array($statusId, [1, 2, 3, 4, 5], true)) {
            throw new HttpError('Invalid lead status.', 400);
        }
        $sql .= ' AND l.status_id = ?';
        $params[] = $statusId;
    }
    if (!empty($_GET['priority'])) {
        if (!in_array($_GET['priority'], ['urgent', 'high', 'medium', 'low'], true)) {
            throw new HttpError('Invalid lead priority.', 400);
        }
        $sql .= ' AND l.priority = ?';
        $params[] = $_GET['priority'];
    }
    if (!empty($_GET['q'])) {
        $like = '%' . substr(trim((string) $_GET['q']), 0, 100) . '%';
        $sql .= ' AND (l.full_name LIKE ? OR l.mobile LIKE ? OR l.lead_code LIKE ? OR l.city LIKE ?)';
        array_push($params, $like, $like, $like, $like);
    }
    $count = (int) db_one("SELECT COUNT(*) AS c FROM leads l WHERE $sql", $params)['c'];
    $rows = db_all(lead_select_sql() . " WHERE $sql ORDER BY l.created_at DESC LIMIT 500", $params);
    if (($_GET['unassigned'] ?? '') === '1' && ($_GET['sort'] ?? '') === 'priority') {
        $rank = ['urgent' => 0, 'high' => 1, 'medium' => 2, 'low' => 3];
        usort($rows, function ($a, $b) use ($rank) {
            return ($rank[$a['priority']] ?? 99) <=> ($rank[$b['priority']] ?? 99);
        });
    }
    json_out([
        'success' => true,
        'data' => array_map('serialize_lead', $rows),
        'meta' => ['total' => $count],
    ]);
}

function handle_lead_get($id)
{
    $user = require_user();
    $leadId = int_id($id, 'lead ID');
    $lead = fetch_lead($leadId);
    if (!$lead) {
        throw new HttpError('Lead not found.', 404);
    }
    assert_lead_visible($user, $lead);
    $notes = db_all(
        'SELECT n.id, n.note, n.created_at, u.full_name AS author_name
         FROM lead_notes n JOIN users u ON u.id = n.author_id
         WHERE n.lead_id = ? ORDER BY n.created_at DESC',
        [$leadId]
    );
    $assignments = db_all(
        'SELECT a.id, a.method, a.created_at, tu.full_name AS to_name, fu.full_name AS from_name, bu.full_name AS by_name
         FROM lead_assignments a
         LEFT JOIN users tu ON tu.id = a.to_user_id
         LEFT JOIN users fu ON fu.id = a.from_user_id
         LEFT JOIN users bu ON bu.id = a.assigned_by
         WHERE a.lead_id = ? ORDER BY a.created_at DESC',
        [$leadId]
    );
    $calls = db_all(
        'SELECT c.id, c.outcome, c.notes, c.started_at, c.duration_seconds, u.full_name AS employee_name
         FROM lead_calls c JOIN users u ON u.id = c.employee_id
         WHERE c.lead_id = ? ORDER BY c.started_at DESC',
        [$leadId]
    );
    json_ok([
        'lead' => serialize_lead($lead),
        'notes' => array_map(function ($note) {
            return [
                'id' => (string) $note['id'],
                'note' => $note['note'],
                'author_name' => $note['author_name'],
                'created_at' => iso_dt($note['created_at']),
            ];
        }, $notes),
        'assignments' => array_map(function ($row) {
            return [
                'id' => (string) $row['id'],
                'method' => $row['method'],
                'from_name' => $row['from_name'],
                'to_name' => $row['to_name'],
                'by_name' => $row['by_name'],
                'created_at' => iso_dt($row['created_at']),
            ];
        }, $assignments),
        'calls' => array_map(function ($call) {
            return [
                'id' => (string) $call['id'],
                'outcome' => $call['outcome'],
                'notes' => $call['notes'],
                'employee_name' => $call['employee_name'],
                'initiated_at' => iso_dt($call['started_at']),
                'duration_seconds' => (int) $call['duration_seconds'],
            ];
        }, $calls),
    ]);
}

function insert_lead($input, $companyId, $ownerId, $createdBy)
{
    $id = db_insert(
        'INSERT INTO leads (company_id, lead_code, full_name, mobile, email, city, location, property_type, budget_min, budget_max, preferred_configuration, source_id, priority, requirements, consent_whatsapp, status_id, owner_id, created_by, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
            $companyId,
            'TMP-' . bin2hex(random_bytes(8)),
            $input['full_name'],
            $input['mobile'],
            $input['email'],
            $input['city'],
            $input['location'],
            $input['property_type'],
            $input['budget_min'],
            $input['budget_max'],
            $input['preferred_configuration'],
            $input['source_id'],
            $input['priority'],
            $input['requirements'],
            $input['consent_whatsapp'],
            $input['status_id'],
            $ownerId,
            $createdBy,
            utc_now(),
            utc_now(),
        ]
    );
    $code = 'LD-' . str_pad((string) $id, 6, '0', STR_PAD_LEFT);
    db_exec('UPDATE leads SET lead_code = ? WHERE id = ?', [$code, $id]);
    return fetch_lead($id);
}

function handle_lead_create()
{
    $user = require_user();
    if ($user['role'] === 'super_admin') {
        throw new HttpError('Super Admin has read-only access to leads.', 403);
    }
    $body = request_data();
    $input = normalize_lead_input($body);
    $companyId = lead_company_id($user);
    $ownerId = $user['role'] === 'employee' ? (int) $user['id'] : null;
    $lead = insert_lead($input, $companyId, $ownerId, (int) $user['id']);
    if (!empty($body['auto_assign']) && $user['role'] === 'admin') {
        $method = (string) ($body['assign_method'] ?? 'round_robin');
        if (!in_array($method, ['manual', 'round_robin', 'workload', 'priority'], true)) {
            $method = 'round_robin';
        }
        if ($method !== 'manual') {
            $assignee = pick_assignee($companyId, $method);
            assign_lead_to($lead, $assignee, $user, $method);
            $lead = fetch_lead($lead['id']);
        }
    }
    audit_write('create_lead', 'lead', $lead['id']);
    json_out(['success' => true, 'data' => serialize_lead($lead)], 201);
}

function handle_lead_update($id)
{
    $user = require_user();
    $leadId = int_id($id, 'lead ID');
    $lead = fetch_lead($leadId);
    if (!$lead) {
        throw new HttpError('Lead not found.', 404);
    }
    assert_lead_visible($user, $lead);
    if ($user['role'] === 'super_admin') {
        throw new HttpError('Super Admin has read-only access to leads.', 403);
    }
    $body = request_data();
    if (isset($body['status_id'])) {
        $statusId = (int) $body['status_id'];
        if (!in_array($statusId, [1, 2, 3, 4, 5], true)) {
            throw new HttpError('Invalid lead status.', 400);
        }
        db_exec('UPDATE leads SET status_id = ? WHERE id = ?', [$statusId, $leadId]);
        audit_write('update_lead_status', 'lead', $leadId);
    }
    json_ok(serialize_lead(fetch_lead($leadId)));
}

function handle_lead_assign($id)
{
    $user = require_user();
    if (!in_array($user['role'], ['admin', 'team_lead'], true)) {
        throw new HttpError('Only Admins and Team Leads can assign leads.', 403);
    }
    $leadId = int_id($id, 'lead ID');
    $lead = fetch_lead($leadId);
    if (!$lead || (int) $lead['company_id'] !== (int) $user['company_id']) {
        throw new HttpError('Lead not found.', 404);
    }
    $body = request_data();
    $method = (string) ($body['method'] ?? 'round_robin');
    if (!in_array($method, ['manual', 'round_robin', 'workload', 'priority'], true)) {
        throw new HttpError('Invalid assignment method.', 400);
    }
    if ($method === 'manual') {
        $employeeId = int_id($body['employee_id'] ?? null, 'employee ID');
        $assignee = db_one(
            "SELECT * FROM users WHERE id = ? AND company_id = ? AND is_active = 1 AND role IN ('employee','team_lead')",
            [$employeeId, (int) $user['company_id']]
        );
        if (!$assignee) {
            throw new HttpError('That employee cannot receive this lead.', 400);
        }
        if ($user['role'] === 'team_lead' && (int) $assignee['team_id'] !== (int) $user['team_id'] && (int) $assignee['id'] !== (int) $user['id']) {
            throw new HttpError('You can only assign leads inside your team.', 403);
        }
    } else {
        $assignee = pick_assignee((int) $user['company_id'], $method, $user['role'] === 'team_lead' ? (int) $user['team_id'] : null);
    }
    assign_lead_to($lead, $assignee, $user, $method);
    json_ok(serialize_lead(fetch_lead($leadId)));
}

function handle_lead_note($id)
{
    $user = require_user();
    $leadId = int_id($id, 'lead ID');
    $lead = fetch_lead($leadId);
    if (!$lead) {
        throw new HttpError('Lead not found.', 404);
    }
    assert_lead_visible($user, $lead);
    $body = request_data();
    $note = trim((string) ($body['note'] ?? ''));
    if ($note === '') {
        throw new HttpError('Enter a note.', 400);
    }
    $noteId = db_insert(
        'INSERT INTO lead_notes (lead_id, author_id, note, created_at) VALUES (?, ?, ?, ?)',
        [$leadId, (int) $user['id'], $note, utc_now()]
    );
    audit_write('add_note', 'lead', $leadId);
    json_out(['success' => true, 'data' => ['id' => (string) $noteId, 'note' => $note]], 201);
}

function handle_lead_calls($id)
{
    $user = require_user();
    $leadId = int_id($id, 'lead ID');
    $lead = fetch_lead($leadId);
    if (!$lead) {
        throw new HttpError('Lead not found.', 404);
    }
    assert_lead_visible($user, $lead);
    $rows = db_all(
        'SELECT c.*, u.full_name AS employee_name FROM lead_calls c JOIN users u ON u.id = c.employee_id WHERE c.lead_id = ? ORDER BY c.started_at DESC',
        [$leadId]
    );
    json_ok(array_map(function ($call) use ($lead) {
        return [
            'id' => (string) $call['id'],
            'lead_id' => (string) $lead['id'],
            'lead_name' => $lead['full_name'],
            'mobile' => $lead['mobile'],
            'employee_name' => $call['employee_name'],
            'outcome' => $call['outcome'],
            'notes' => $call['notes'],
            'initiated_at' => iso_dt($call['started_at']),
            'duration_seconds' => (int) $call['duration_seconds'],
            'status' => $call['status'],
        ];
    }, $rows));
}

function handle_lead_call_end($id)
{
    $user = require_user();
    $leadId = int_id($id, 'lead ID');
    $lead = fetch_lead($leadId);
    if (!$lead) {
        throw new HttpError('Lead not found.', 404);
    }
    assert_lead_visible($user, $lead);
    $body = request_data();
    $outcome = (string) ($body['outcome'] ?? 'other');
    $allowed = ['answered', 'interested', 'callback_requested', 'no_answer', 'busy', 'switched_off', 'not_interested', 'invalid_number', 'other'];
    if (!in_array($outcome, $allowed, true)) {
        throw new HttpError('Invalid call outcome.', 400);
    }
    $open = db_one(
        "SELECT * FROM lead_calls WHERE lead_id = ? AND employee_id = ? AND status = 'in_progress' ORDER BY id DESC LIMIT 1",
        [$leadId, (int) $user['id']]
    );
    $now = utc_now();
    if ($open) {
        $duration = max(0, strtotime($now . ' UTC') - strtotime($open['started_at'] . ' UTC'));
        db_exec(
            'UPDATE lead_calls SET ended_at = ?, duration_seconds = ?, outcome = ?, notes = ?, status = \'completed\' WHERE id = ?',
            [$now, $duration, $outcome, trim((string) ($body['notes'] ?? '')), (int) $open['id']]
        );
        $callId = (int) $open['id'];
    } else {
        $callId = db_insert(
            'INSERT INTO lead_calls (company_id, lead_id, employee_id, started_at, ended_at, duration_seconds, outcome, notes, status, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, 0, ?, ?, \'completed\', ?, ?)',
            [(int) $lead['company_id'], $leadId, (int) $user['id'], $now, $now, $outcome, trim((string) ($body['notes'] ?? '')), $now, $now]
        );
    }
    audit_write('log_call', 'lead', $leadId);
    json_out(['success' => true, 'data' => ['id' => (string) $callId]], 201);
}

function handle_leads_import()
{
    $user = require_user();
    if (!in_array($user['role'], ['admin', 'team_lead'], true)) {
        throw new HttpError('Only Admins and Team Leads can import leads.', 403);
    }
    $body = request_data();
    $records = $body['records'] ?? null;
    if (!is_array($records) || count($records) === 0) {
        throw new HttpError('Provide a non-empty records array.', 400);
    }
    if (count($records) > 1000) {
        throw new HttpError('Import is limited to 1,000 records per request.', 400);
    }
    $companyId = lead_company_id($user);
    $imported = 0;
    $rejected = [];
    foreach ($records as $index => $record) {
        try {
            $input = normalize_lead_input(is_array($record) ? $record : []);
            insert_lead($input, $companyId, null, (int) $user['id']);
            $imported++;
        } catch (HttpError $error) {
            $rejected[] = ['row' => $index + 1, 'error' => $error->getMessage()];
        }
    }
    audit_write('import_leads', 'lead', null);
    json_ok(['imported' => $imported, 'rejected' => $rejected]);
}

function csv_cell($value)
{
    return '"' . str_replace('"', '""', (string) $value) . '"';
}

function handle_leads_export()
{
    $user = require_user();
    $params = [];
    $sql = visible_lead_sql($user, $params);
    $rows = db_all(lead_select_sql() . " WHERE $sql ORDER BY l.created_at DESC", $params);
    $lines = ['lead_code,full_name,mobile,city,priority,status,owner'];
    foreach ($rows as $lead) {
        $lines[] = implode(',', [
            csv_cell($lead['lead_code']),
            csv_cell($lead['full_name']),
            csv_cell($lead['mobile']),
            csv_cell($lead['city']),
            csv_cell($lead['priority']),
            csv_cell(status_name($lead['status_id'])),
            csv_cell($lead['owner_name'] ?? ''),
        ]);
    }
    json_ok(['csv' => implode("\n", $lines)]);
}
