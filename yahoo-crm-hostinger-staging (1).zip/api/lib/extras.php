<?php

function require_company_user()
{
    $user = require_user();
    if ($user['role'] !== 'super_admin' && empty($user['company_id'])) {
        throw new HttpError('Your account is not assigned to a company.', 403);
    }
    return $user;
}

function company_rows_sql($user, $column)
{
    if ($user['role'] === 'super_admin') {
        return ['1 = 1', []];
    }
    return [$column . ' = ?', [(int) $user['company_id']]];
}

function handle_teams_list()
{
    $user = require_company_user();
    if (!in_array($user['role'], ['admin', 'team_lead', 'super_admin'], true)) {
        throw new HttpError('You do not have permission to view teams.', 403);
    }
    [$where, $params] = company_rows_sql($user, 't.company_id');
    if ($user['role'] === 'team_lead') {
        $where .= ' AND t.id = ?';
        $params[] = (int) $user['team_id'];
    }
    $rows = db_all(
        "SELECT t.*, u.full_name AS team_lead_name,
            (SELECT COUNT(*) FROM users m WHERE m.team_id = t.id) AS member_count
         FROM teams t
         LEFT JOIN users u ON u.id = t.team_lead_id
         WHERE $where
         ORDER BY t.name",
        $params
    );
    json_ok(array_map(function ($row) {
        return [
            'id' => (string) $row['id'],
            'name' => $row['name'],
            'description' => $row['description'],
            'team_lead_id' => $row['team_lead_id'] ? (string) $row['team_lead_id'] : null,
            'team_lead_name' => $row['team_lead_name'],
            'member_count' => (int) $row['member_count'],
            'is_active' => (bool) $row['is_active'],
            'company_id' => (string) $row['company_id'],
        ];
    }, $rows));
}

function handle_team_create()
{
    $user = require_role('admin', 'super_admin');
    $body = request_data();
    $name = trim((string) ($body['name'] ?? ''));
    if ($name === '') {
        throw new HttpError('Team name is required.', 400);
    }
    $companyId = $user['role'] === 'super_admin' ? ($body['company_id'] ?? null) : $user['company_id'];
    if (!$companyId) {
        throw new HttpError('company_id is required.', 400);
    }
    $id = db_insert(
        'INSERT INTO teams (company_id, name, description, is_active, created_at, updated_at) VALUES (?, ?, ?, 1, ?, ?)',
        [(int) $companyId, $name, trim((string) ($body['description'] ?? '')), utc_now(), utc_now()]
    );
    audit_write('create_team', 'team', $id);
    json_out(['success' => true, 'data' => ['id' => (string) $id, 'name' => $name]], 201);
}

function handle_team_members($id)
{
    $user = require_company_user();
    $teamId = int_id($id, 'team ID');
    $team = db_one('SELECT * FROM teams WHERE id = ?', [$teamId]);
    if (!$team) {
        throw new HttpError('Team not found.', 404);
    }
    if ($user['role'] !== 'super_admin' && (int) $team['company_id'] !== (int) $user['company_id']) {
        throw new HttpError('You do not have permission to view this team.', 403);
    }
    if ($user['role'] === 'team_lead' && (int) $user['team_id'] !== $teamId) {
        throw new HttpError('You do not have permission to view this team.', 403);
    }
    $rows = db_all(
        'SELECT id, full_name, role, employee_code, email, is_active FROM users WHERE team_id = ? ORDER BY full_name',
        [$teamId]
    );
    json_ok(array_map(function ($row) {
        return [
            'id' => (string) $row['id'],
            'full_name' => $row['full_name'],
            'role' => $row['role'],
            'employee_code' => $row['employee_code'],
            'email' => $row['email'],
            'is_active' => (bool) $row['is_active'],
        ];
    }, $rows));
}

function shape_property($row)
{
    return [
        'id' => (string) $row['id'],
        'property_code' => 'PR-' . str_pad((string) $row['id'], 6, '0', STR_PAD_LEFT),
        'name' => $row['name'],
        'property_type' => $row['property_type'],
        'city' => $row['city'],
        'location' => $row['location'],
        'price_min' => $row['price_min'] !== null ? (float) $row['price_min'] : null,
        'price_max' => $row['price_max'] !== null ? (float) $row['price_max'] : null,
        'configuration' => $row['configuration'],
        'availability_status' => $row['status'],
        'status' => $row['status'],
        'company_id' => (string) $row['company_id'],
    ];
}

function handle_properties_list()
{
    $user = require_company_user();
    [$where, $params] = company_rows_sql($user, 'company_id');
    $rows = db_all("SELECT * FROM properties WHERE $where ORDER BY name", $params);
    json_ok(array_map('shape_property', $rows));
}

function handle_property_create()
{
    $user = require_role('admin', 'super_admin');
    $body = request_data();
    $name = trim((string) ($body['name'] ?? ''));
    if ($name === '') {
        throw new HttpError('Property name is required.', 400);
    }
    $companyId = $user['role'] === 'super_admin' ? ($body['company_id'] ?? $user['company_id']) : $user['company_id'];
    if (!$companyId) {
        throw new HttpError('company_id is required.', 400);
    }
    $types = ['apartment', 'villa', 'plot', 'commercial', 'other'];
    $type = in_array($body['property_type'] ?? 'apartment', $types, true) ? $body['property_type'] : 'apartment';
    $id = db_insert(
        'INSERT INTO properties (company_id, name, property_type, city, location, price_min, price_max, configuration, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, \'available\', ?, ?)',
        [
            (int) $companyId,
            $name,
            $type,
            trim((string) ($body['city'] ?? '')),
            trim((string) ($body['location'] ?? '')),
            $body['price_min'] === '' || $body['price_min'] === null ? null : (float) $body['price_min'],
            $body['price_max'] === '' || $body['price_max'] === null ? null : (float) $body['price_max'],
            trim((string) ($body['configuration'] ?? '2 BHK')) ?: '2 BHK',
            utc_now(),
            utc_now(),
        ]
    );
    audit_write('create_property', 'property', $id);
    json_out(['success' => true, 'data' => shape_property(db_one('SELECT * FROM properties WHERE id = ?', [$id]))], 201);
}

function handle_property_matches($id)
{
    $user = require_company_user();
    $property = db_one('SELECT * FROM properties WHERE id = ?', [int_id($id, 'property ID')]);
    if (!$property) {
        throw new HttpError('Property not found.', 404);
    }
    if ($user['role'] !== 'super_admin' && (int) $property['company_id'] !== (int) $user['company_id']) {
        throw new HttpError('You do not have permission to view this property.', 403);
    }
    $params = [(int) $property['company_id'], $property['property_type']];
    $sql = 'SELECT l.*, o.full_name AS owner_name FROM leads l LEFT JOIN users o ON o.id = l.owner_id
            WHERE l.company_id = ? AND l.property_type = ?';
    if ($property['city'] !== '') {
        $sql .= ' AND LOWER(l.city) = LOWER(?)';
        $params[] = $property['city'];
    }
    if ($property['price_min'] !== null) {
        $sql .= ' AND (l.budget_max IS NULL OR l.budget_max >= ?)';
        $params[] = $property['price_min'];
    }
    if ($property['price_max'] !== null) {
        $sql .= ' AND (l.budget_min IS NULL OR l.budget_min <= ?)';
        $params[] = $property['price_max'];
    }
    $rows = db_all($sql . ' ORDER BY l.created_at DESC LIMIT 100', $params);
    json_ok(array_map(function ($lead) {
        return [
            'id' => (string) $lead['id'],
            'full_name' => $lead['full_name'],
            'city' => $lead['city'],
            'preferred_configuration' => $lead['preferred_configuration'],
            'status_name' => status_name($lead['status_id']),
            'mobile' => $lead['mobile'],
        ];
    }, $rows));
}

function handle_notifications_list()
{
    $user = require_user();
    $rows = db_all('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 100', [(int) $user['id']]);
    $unread = (int) db_one('SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0', [(int) $user['id']])['c'];
    json_ok(array_map(function ($row) {
        return [
            'id' => (string) $row['id'],
            'title' => $row['title'],
            'body' => $row['body'],
            'link_path' => $row['link_path'],
            'is_read' => (bool) $row['is_read'],
            'created_at' => iso_dt($row['created_at']),
        ];
    }, $rows), 200, ['meta' => ['unread' => $unread]]);
}

function handle_notification_read($id)
{
    $user = require_user();
    db_exec('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?', [int_id($id, 'notification ID'), (int) $user['id']]);
    json_ok(['id' => (string) $id, 'is_read' => true]);
}

function handle_notifications_read_all()
{
    $user = require_user();
    db_exec('UPDATE notifications SET is_read = 1 WHERE user_id = ?', [(int) $user['id']]);
    json_ok(['unread' => 0]);
}

function default_office_hours()
{
    return ['start' => '09:30', 'end' => '18:30', 'grace_minutes' => 15, 'weekly_holidays' => [0]];
}

function load_settings_map($companyId)
{
    $rows = db_all('SELECT setting_key, value_json FROM company_settings WHERE company_id = ?', [(int) $companyId]);
    $data = ['office_hours' => default_office_hours()];
    foreach ($rows as $row) {
        $decoded = json_decode($row['value_json'], true);
        $data[$row['setting_key']] = $decoded === null ? $row['value_json'] : $decoded;
    }
    return $data;
}

function handle_settings_get()
{
    $user = require_role('admin');
    json_ok(load_settings_map($user['company_id']));
}

function handle_settings_save()
{
    $user = require_role('admin');
    $body = request_data();
    $key = (string) ($body['key'] ?? '');
    if (!preg_match('/^[a-z0-9_]{1,64}$/', $key)) {
        throw new HttpError('Invalid settings key.', 400);
    }
    if (!array_key_exists('value', $body)) {
        throw new HttpError('Settings value is required.', 400);
    }
    $json = json_encode($body['value']);
    $existing = db_one('SELECT id FROM company_settings WHERE company_id = ? AND setting_key = ?', [(int) $user['company_id'], $key]);
    if ($existing) {
        db_exec('UPDATE company_settings SET value_json = ? WHERE id = ?', [$json, (int) $existing['id']]);
    } else {
        db_insert(
            'INSERT INTO company_settings (company_id, setting_key, value_json) VALUES (?, ?, ?)',
            [(int) $user['company_id'], $key, $json]
        );
    }
    audit_write('update_settings', 'settings', $key);
    json_ok(load_settings_map($user['company_id']));
}

function handle_assignment_rules()
{
    $user = require_user();
    if (!in_array($user['role'], ['admin', 'team_lead'], true) || empty($user['company_id'])) {
        throw new HttpError('You do not have permission to view assignment rules.', 403);
    }
    $rows = db_all('SELECT * FROM assignment_rules WHERE company_id = ? ORDER BY sort_order, id', [(int) $user['company_id']]);
    json_ok(array_map(function ($row) {
        return [
            'id' => (string) $row['id'],
            'name' => $row['name'],
            'method' => $row['method'],
            'team_id' => $row['team_id'] ? (string) $row['team_id'] : null,
            'is_active' => (bool) $row['is_active'],
            'sort_order' => (int) $row['sort_order'],
        ];
    }, $rows));
}

function handle_assignment_queues()
{
    $user = require_role('admin');
    $rows = db_all('SELECT * FROM assignment_queues WHERE company_id = ? ORDER BY queue_key', [(int) $user['company_id']]);
    json_ok(array_map(function ($row) {
        return [
            'id' => (string) $row['id'],
            'queue_key' => $row['queue_key'],
            'method' => $row['method'],
            'last_user_id' => $row['last_user_id'] ? (string) $row['last_user_id'] : null,
            'is_paused' => (bool) $row['is_paused'],
        ];
    }, $rows));
}

function handle_queue_pause()
{
    $user = require_role('admin');
    $body = request_data();
    $key = trim((string) ($body['queue_key'] ?? ''));
    if ($key === '') {
        throw new HttpError('queue_key is required.', 400);
    }
    $paused = !empty($body['is_paused']) ? 1 : 0;
    $row = db_one('SELECT id FROM assignment_queues WHERE company_id = ? AND queue_key = ?', [(int) $user['company_id'], $key]);
    if (!$row) {
        throw new HttpError('Assignment queue not found.', 404);
    }
    db_exec('UPDATE assignment_queues SET is_paused = ? WHERE id = ?', [$paused, (int) $row['id']]);
    audit_write($paused ? 'pause_queue' : 'resume_queue', 'queue', $key);
    json_ok(['queue_key' => $key, 'is_paused' => (bool) $paused]);
}

function handle_queue_reset()
{
    $user = require_role('admin');
    $body = request_data();
    $key = trim((string) ($body['queue_key'] ?? ''));
    $row = db_one('SELECT id FROM assignment_queues WHERE company_id = ? AND queue_key = ?', [(int) $user['company_id'], $key]);
    if (!$row) {
        throw new HttpError('Assignment queue not found.', 404);
    }
    db_exec('UPDATE assignment_queues SET last_user_id = NULL WHERE id = ?', [(int) $row['id']]);
    audit_write('reset_queue', 'queue', $key);
    json_ok(['queue_key' => $key, 'last_user_id' => null]);
}

function handle_nurturing_list()
{
    $user = require_user();
    if (!in_array($user['role'], ['admin', 'team_lead', 'super_admin'], true)) {
        throw new HttpError('You do not have permission to view nurturing sequences.', 403);
    }
    [$where, $params] = company_rows_sql($user, 'company_id');
    if ($user['role'] === 'super_admin') {
        $rows = db_all('SELECT * FROM nurturing_sequences ORDER BY name');
    } else {
        $rows = db_all("SELECT * FROM nurturing_sequences WHERE $where ORDER BY name", $params);
    }
    $data = [];
    foreach ($rows as $row) {
        $steps = db_all('SELECT * FROM nurturing_steps WHERE sequence_id = ? ORDER BY step_order', [(int) $row['id']]);
        $data[] = [
            'id' => (string) $row['id'],
            'name' => $row['name'],
            'objective' => $row['objective'],
            'is_active' => (bool) $row['is_active'],
            'steps' => array_map(function ($step) {
                return [
                    'id' => (string) $step['id'],
                    'step_order' => (int) $step['step_order'],
                    'action_type' => $step['action_type'],
                    'delay_hours' => (int) $step['delay_hours'],
                    'task_title' => $step['task_title'],
                ];
            }, $steps),
        ];
    }
    json_ok($data);
}

function handle_nurturing_toggle($id)
{
    $user = require_role('admin', 'super_admin');
    $sequenceId = int_id($id, 'sequence ID');
    $row = db_one('SELECT * FROM nurturing_sequences WHERE id = ?', [$sequenceId]);
    if (!$row) {
        throw new HttpError('Nurturing sequence not found.', 404);
    }
    if ($user['role'] !== 'super_admin' && (int) $row['company_id'] !== (int) $user['company_id']) {
        throw new HttpError('You do not have permission to change this sequence.', 403);
    }
    $body = request_data();
    $active = !empty($body['is_active']) ? 1 : 0;
    db_exec('UPDATE nurturing_sequences SET is_active = ? WHERE id = ?', [$active, $sequenceId]);
    audit_write('toggle_nurturing', 'nurturing', $sequenceId);
    json_ok(['id' => (string) $sequenceId, 'is_active' => (bool) $active]);
}

function handle_audit_logs()
{
    $user = require_user();
    if (!in_array($user['role'], ['admin', 'super_admin'], true)) {
        throw new HttpError('You do not have permission to view audit logs.', 403);
    }
    if ($user['role'] === 'super_admin') {
        $rows = db_all('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 300');
    } else {
        $rows = db_all(
            'SELECT a.* FROM audit_logs a LEFT JOIN users u ON u.id = a.actor_id
             WHERE u.company_id = ? OR a.actor_id = ? ORDER BY a.created_at DESC LIMIT 300',
            [(int) $user['company_id'], (int) $user['id']]
        );
    }
    json_ok(array_map(function ($row) {
        return [
            'id' => (string) $row['id'],
            'created_at' => iso_dt($row['created_at']),
            'actor_name' => $row['actor_name'],
            'action' => $row['action'],
            'entity_type' => $row['entity_type'],
            'entity_id' => $row['entity_id'],
        ];
    }, $rows));
}

function handle_whatsapp_status()
{
    require_user();
    json_ok([
        'mode' => 'not_configured',
        'live' => false,
        'dependency' => 'Meta WhatsApp Cloud API credentials are not configured. Messages are not sent.',
    ]);
}

function handle_whatsapp_send()
{
    require_user();
    throw new HttpError('WhatsApp Cloud API is not configured. No message was sent.', 503);
}

function month_bounds($month)
{
    if (!is_string($month) || !preg_match('/^\d{4}-\d{2}$/', $month)) {
        $month = gmdate('Y-m');
    }
    $start = $month . '-01';
    $days = (int) gmdate('t', strtotime($start . ' UTC'));
    return [$month, $start, $month . '-' . str_pad((string) $days, 2, '0', STR_PAD_LEFT), $days];
}

function employee_month_attendance($user, $month)
{
    [$month, $from, $to, $daysInMonth] = month_bounds($month);
    $rows = db_all(
        'SELECT * FROM attendance WHERE user_id = ? AND work_date >= ? AND work_date <= ?',
        [(int) $user['id'], $from, $to]
    );
    $byDate = [];
    foreach ($rows as $row) {
        $byDate[$row['work_date']] = $row;
    }
    $settings = $user['company_id'] ? load_settings_map($user['company_id']) : ['office_hours' => default_office_hours()];
    $office = $settings['office_hours'] ?? default_office_hours();
    $timezone = $user['timezone'] ?: 'Asia/Kolkata';
    $today = work_date($timezone);
    $holidays = $office['weekly_holidays'] ?? [0];
    $summary = [
        'working_days' => 0,
        'present' => 0,
        'absent' => 0,
        'leave' => 0,
        'late' => 0,
        'early_logout' => 0,
        'missing_logout' => 0,
        'holidays' => 0,
        'working_seconds' => 0,
        'break_seconds' => 0,
        'session_seconds' => 0,
    ];
    $days = [];
    for ($d = 1; $d <= $daysInMonth; $d++) {
        $date = $month . '-' . str_pad((string) $d, 2, '0', STR_PAD_LEFT);
        $weekday = (int) gmdate('w', strtotime($date . ' UTC'));
        $record = $byDate[$date] ?? null;
        $login = null;
        $logout = null;
        $working = 0;
        $brk = 0;
        $late = false;
        $early = false;
        if ($date > $today) {
            $status = 'upcoming';
        } elseif (in_array($weekday, $holidays, true) && !$record) {
            $status = 'holiday';
            if ($date <= $today) {
                $summary['holidays']++;
            }
        } elseif (!$record) {
            $status = $date === $today ? 'not_logged_in' : 'absent';
            if ($date < $today && !in_array($weekday, $holidays, true)) {
                $summary['absent']++;
                $summary['working_days']++;
            } elseif ($date === $today && !in_array($weekday, $holidays, true)) {
                $summary['working_days']++;
            }
        } else {
            $sessions = attendance_sessions($record);
            $time = attendance_durations($sessions);
            $working = $time['working_seconds'];
            $brk = $time['break_seconds'];
            $login = $sessions[0]['login_at'] ?? $record['login_at'];
            $open = false;
            foreach ($sessions as $session) {
                if (empty($session['logout_at'])) {
                    $open = true;
                }
            }
            $logout = $open ? null : ($sessions[count($sessions) - 1]['logout_at'] ?? $record['logout_at']);
            $local = new DateTime($login, new DateTimeZone('UTC'));
            $local->setTimezone(new DateTimeZone($timezone));
            $grace = (int) ($office['grace_minutes'] ?? 0);
            $cutoff = DateTime::createFromFormat('Y-m-d H:i', $date . ' ' . ($office['start'] ?? '09:30'), new DateTimeZone($timezone));
            if ($cutoff) {
                $cutoff->modify('+' . $grace . ' minutes');
                $late = $local > $cutoff;
            }
            if ($logout) {
                $endLocal = new DateTime($logout, new DateTimeZone('UTC'));
                $endLocal->setTimezone(new DateTimeZone($timezone));
                $officeEnd = DateTime::createFromFormat('Y-m-d H:i', $date . ' ' . ($office['end'] ?? '18:30'), new DateTimeZone($timezone));
                $early = $officeEnd && $endLocal < $officeEnd;
            }
            $status = $open ? 'in_progress' : ($late ? 'late' : 'present');
            if ($open && $date < $today) {
                $status = 'missing_logout';
                $summary['missing_logout']++;
            }
            $summary['present']++;
            $summary['late'] += $late ? 1 : 0;
            $summary['early_logout'] += $early ? 1 : 0;
            $summary['working_seconds'] += $working;
            $summary['break_seconds'] += $brk;
            $summary['session_seconds'] += $time['session_seconds'];
            if (!in_array($weekday, $holidays, true) && $date <= $today) {
                $summary['working_days']++;
            }
        }
        $days[] = [
            'date' => $date,
            'weekday' => $weekday,
            'status' => $status,
            'login_at' => iso_dt($login),
            'logout_at' => iso_dt($logout),
            'working_seconds' => $working,
            'break_seconds' => $brk,
            'is_late' => $late,
            'is_early_logout' => $early,
        ];
    }
    $summary['avg_working_seconds'] = (int) round($summary['working_seconds'] / max(1, $summary['present']));
    $summary['attendance_rate'] = $summary['working_days']
        ? round((100 * $summary['present']) / $summary['working_days'], 1)
        : 0;
    return [
        'month' => $month,
        'from' => $from,
        'to' => $to,
        'days' => $days,
        'summary' => $summary,
        'note' => 'Attendance is calculated from check-in records. Approved leave is not stored as a separate status.',
    ];
}

function workspace_leads($user)
{
    $params = [];
    $where = visible_lead_sql($user, $params);
    $rows = db_all(lead_select_sql() . " WHERE $where ORDER BY l.updated_at DESC LIMIT 300", $params);
    $data = [];
    foreach ($rows as $lead) {
        $calls = db_one('SELECT COUNT(*) AS c, MAX(started_at) AS last_at FROM lead_calls WHERE lead_id = ?', [(int) $lead['id']]);
        $shaped = serialize_lead($lead);
        $shaped['call_count'] = (int) $calls['c'];
        $shaped['last_contact_at'] = iso_dt($calls['last_at']);
        $data[] = $shaped;
    }
    return $data;
}

function employee_performance($user, $leads)
{
    $daily = [];
    for ($i = 13; $i >= 0; $i--) {
        $date = gmdate('Y-m-d', strtotime("-$i day"));
        $next = gmdate('Y-m-d H:i:s', strtotime($date . ' +1 day'));
        $calls = (int) db_one(
            'SELECT COUNT(*) AS c FROM lead_calls WHERE employee_id = ? AND started_at >= ? AND started_at < ?',
            [(int) $user['id'], $date . ' 00:00:00', $next]
        )['c'];
        $connected = (int) db_one(
            "SELECT COUNT(*) AS c FROM lead_calls WHERE employee_id = ? AND started_at >= ? AND started_at < ? AND outcome IN ('answered','interested','callback_requested')",
            [(int) $user['id'], $date . ' 00:00:00', $next]
        )['c'];
        $done = (int) db_one(
            'SELECT COUNT(*) AS c FROM follow_ups WHERE employee_id = ? AND status = \'completed\' AND completed_at >= ? AND completed_at < ?',
            [(int) $user['id'], $date . ' 00:00:00', $next]
        )['c'];
        $daily[] = ['date' => $date, 'calls' => $calls, 'connected' => $connected, 'follow_ups_done' => $done];
    }
    $monthStart = gmdate('Y-m-01 00:00:00');
    $callsMonth = (int) db_one('SELECT COUNT(*) AS c FROM lead_calls WHERE employee_id = ? AND started_at >= ?', [(int) $user['id'], $monthStart])['c'];
    $connectedMonth = (int) db_one(
        "SELECT COUNT(*) AS c FROM lead_calls WHERE employee_id = ? AND started_at >= ? AND outcome IN ('answered','interested','callback_requested','not_interested')",
        [(int) $user['id'], $monthStart]
    )['c'];
    $outcomes = db_all(
        'SELECT outcome, COUNT(*) AS cnt FROM lead_calls WHERE employee_id = ? AND started_at >= ? GROUP BY outcome',
        [(int) $user['id'], $monthStart]
    );
    $completed = (int) db_one(
        'SELECT COUNT(*) AS c FROM follow_ups WHERE employee_id = ? AND status = \'completed\' AND due_at >= ?',
        [(int) $user['id'], $monthStart]
    )['c'];
    $due = (int) db_one(
        'SELECT COUNT(*) AS c FROM follow_ups WHERE employee_id = ? AND due_at >= ?',
        [(int) $user['id'], $monthStart]
    )['c'];
    $interested = 0;
    foreach ($leads as $lead) {
        if ((int) $lead['status_id'] === 2) {
            $interested++;
        }
    }
    $peers = [];
    if (!empty($user['team_id'])) {
        $peers = db_all('SELECT id FROM users WHERE team_id = ? AND is_active = 1', [(int) $user['team_id']]);
    }
    $rank = 1;
    foreach ($peers as $peer) {
        if ((int) $peer['id'] === (int) $user['id']) {
            continue;
        }
        $peerCalls = (int) db_one('SELECT COUNT(*) AS c FROM lead_calls WHERE employee_id = ? AND started_at >= ?', [(int) $peer['id'], $monthStart])['c'];
        if ($peerCalls > $callsMonth) {
            $rank++;
        }
    }
    $pipeline = [];
    foreach (lead_statuses() as $status) {
        $count = 0;
        foreach ($leads as $lead) {
            if ((int) $lead['status_id'] === (int) $status['id']) {
                $count++;
            }
        }
        if ($count) {
            $pipeline[] = ['name' => $status['name'], 'code' => (string) $status['id'], 'cnt' => $count];
        }
    }
    return [
        'daily' => $daily,
        'monthly' => array_map(function ($offset) use ($user) {
            $start = new DateTime('first day of this month', new DateTimeZone('UTC'));
            $start->modify('-' . $offset . ' months');
            $end = clone $start;
            $end->modify('+1 month');
            $calls = (int) db_one(
                'SELECT COUNT(*) AS c FROM lead_calls WHERE employee_id = ? AND started_at >= ? AND started_at < ?',
                [(int) $user['id'], $start->format('Y-m-d H:i:s'), $end->format('Y-m-d H:i:s')]
            )['c'];
            $visits = (int) db_one(
                'SELECT COUNT(*) AS c FROM site_visits WHERE employee_id = ? AND scheduled_at >= ? AND scheduled_at < ?',
                [(int) $user['id'], $start->format('Y-m-d H:i:s'), $end->format('Y-m-d H:i:s')]
            )['c'];
            $conversions = (int) db_one(
                'SELECT COUNT(*) AS c FROM leads WHERE owner_id = ? AND status_id = 2 AND updated_at >= ? AND updated_at < ?',
                [(int) $user['id'], $start->format('Y-m-d H:i:s'), $end->format('Y-m-d H:i:s')]
            )['c'];
            return ['month' => $start->format('Y-m'), 'calls' => $calls, 'conversions' => $conversions, 'site_visits' => $visits];
        }, [5, 4, 3, 2, 1, 0]),
        'pipeline' => $pipeline,
        'outcomes_this_month' => array_map(function ($row) {
            return ['outcome' => $row['outcome'], 'cnt' => (int) $row['cnt']];
        }, $outcomes),
        'summary' => [
            'calls_this_month' => $callsMonth,
            'connect_rate' => $callsMonth ? round((100 * $connectedMonth) / $callsMonth, 1) : 0,
            'conversion_rate' => count($leads) ? round((100 * $interested) / count($leads), 1) : 0,
            'follow_up_completion' => $due ? round((100 * $completed) / $due, 1) : 0,
            'conversions_this_month' => $interested,
            'site_visits_this_month' => (int) db_one('SELECT COUNT(*) AS c FROM site_visits WHERE employee_id = ? AND scheduled_at >= ?', [(int) $user['id'], $monthStart])['c'],
            'team_rank' => $peers ? $rank : null,
            'team_size' => count($peers),
        ],
        'definitions' => [
            'connect_rate' => 'Answered, interested, callback, or not-interested outcomes divided by calls logged this month.',
            'conversion_rate' => 'Leads in Interested status divided by leads currently visible to you. A booked status is not stored.',
            'follow_up_completion' => 'Completed follow-ups divided by follow-ups due this month.',
            'team_rank' => 'Position by calls logged this month among active people on your team.',
        ],
    ];
}

function workspace_stats($user, $leads, $calls, $followUps, $visits)
{
    $timezone = $user['timezone'] ?: 'Asia/Kolkata';
    $today = work_date($timezone);
    $zone = new DateTimeZone($timezone);
    $callsToday = 0;
    $connectedToday = 0;
    $connected = ['answered', 'interested', 'callback_requested', 'not_interested'];
    foreach ($calls as $call) {
        if (empty($call['started_at'])) {
            continue;
        }
        $local = new DateTime($call['started_at'], new DateTimeZone('UTC'));
        $local->setTimezone($zone);
        if ($local->format('Y-m-d') !== $today) {
            continue;
        }
        $callsToday++;
        if (in_array($call['outcome'], $connected, true)) {
            $connectedToday++;
        }
    }
    $open = array_filter($followUps, function ($row) {
        return in_array($row['status'], ['pending', 'overdue'], true);
    });
    $dueToday = 0;
    $overdue = 0;
    foreach ($open as $row) {
        $due = substr((string) $row['due_at'], 0, 10);
        if ($due === $today) {
            $dueToday++;
        }
        if ($row['status'] === 'overdue') {
            $overdue++;
        }
    }
    $interested = 0;
    $openLeads = 0;
    $newLeads = 0;
    foreach ($leads as $lead) {
        if ((int) $lead['status_id'] === 2) {
            $interested++;
        }
        if ((int) $lead['status_id'] !== 4) {
            $openLeads++;
        }
        if ((int) $lead['status_id'] === 1) {
            $newLeads++;
        }
    }
    $upcoming = 0;
    foreach ($visits as $visit) {
        if ($visit['status'] === 'scheduled') {
            $upcoming++;
        }
    }
    return [
        'assigned_leads' => count($leads),
        'open_leads' => $openLeads,
        'new_leads' => $newLeads,
        'calls_today' => $callsToday,
        'connected_today' => $connectedToday,
        'follow_ups_today' => $dueToday,
        'overdue_follow_ups' => $overdue,
        'interested' => $interested,
        'converted' => $interested,
        'pending' => count($open),
        'site_visits_upcoming' => $upcoming,
        'definitions' => [
            'new_leads' => 'Leads in New status.',
            'pending' => 'Open follow-up tasks, including overdue tasks.',
            'connected_today' => 'Today\'s calls with an answered, interested, callback, or not-interested outcome.',
            'converted' => 'Leads currently in Interested status. A separate converted status is not stored.',
        ],
    ];
}

function handle_employee_workspace()
{
    $user = require_user();
    $month = $_GET['month'] ?? gmdate('Y-m');
    $leads = workspace_leads($user);
    $callRows = db_all(
        'SELECT c.*, l.full_name AS lead_name, l.mobile, l.next_follow_up_at, u.full_name AS employee_name
         FROM lead_calls c JOIN leads l ON l.id = c.lead_id JOIN users u ON u.id = c.employee_id
         WHERE c.employee_id = ? ORDER BY c.started_at DESC LIMIT 200',
        [(int) $user['id']]
    );
    $followRows = db_all(
        'SELECT f.*, l.full_name AS lead_name, l.mobile, u.full_name AS owner_name
         FROM follow_ups f JOIN leads l ON l.id = f.lead_id JOIN users u ON u.id = f.employee_id
         WHERE f.employee_id = ? ORDER BY f.due_at ASC LIMIT 200',
        [(int) $user['id']]
    );
    $visitRows = db_all(
        'SELECT v.*, l.full_name AS lead_name, l.mobile, u.full_name AS owner_name
         FROM site_visits v JOIN leads l ON l.id = v.lead_id JOIN users u ON u.id = v.employee_id
         WHERE v.employee_id = ? ORDER BY v.scheduled_at ASC LIMIT 200',
        [(int) $user['id']]
    );
    $calls = array_map(function ($row) {
        $shaped = shape_call($row);
        $shaped['next_follow_up_at'] = iso_dt($row['next_follow_up_at']);
        return $shaped;
    }, $callRows);
    $followUps = array_map('shape_followup', $followRows);
    $visits = array_map('shape_visit', $visitRows);
    $attendance = employee_month_attendance($user, $month);
    $todayRecord = db_one('SELECT * FROM attendance WHERE user_id = ? AND work_date = ?', [(int) $user['id'], work_date($user['timezone'] ?: 'Asia/Kolkata')]);
    $today = $todayRecord ? serialize_attendance($todayRecord) : null;
    $onBreak = null;
    if ($today) {
        foreach ($today['breaks'] as $item) {
            if (empty($item['end_at'])) {
                $onBreak = $item['start_at'];
            }
        }
    }
    $session = current_session();
    $team = !empty($user['team_id']) ? db_one('SELECT * FROM teams WHERE id = ?', [(int) $user['team_id']]) : null;
    $manager = null;
    if ($team && $team['team_lead_id']) {
        $manager = db_one('SELECT * FROM users WHERE id = ?', [(int) $team['team_lead_id']]);
    }
    $settings = $user['company_id'] ? load_settings_map($user['company_id']) : ['office_hours' => default_office_hours()];
    json_ok([
        'profile' => [
            'id' => (string) $user['id'],
            'employee_code' => $user['employee_code'],
            'full_name' => $user['full_name'],
            'email' => $user['email'],
            'phone' => $user['phone'],
            'specialization' => $user['specialization'],
            'timezone' => $user['timezone'],
            'role_name' => role_name($user['role']),
            'team_name' => $team['name'] ?? null,
            'manager_name' => $manager['full_name'] ?? null,
            'manager_email' => $manager['email'] ?? null,
            'last_login_at' => iso_dt($user['last_login_at']),
        ],
        'session' => [
            'current' => $session ? [
                'login_at' => iso_dt($session['created_at']),
                'expires_at' => iso_dt($session['expires_at']),
                'ip_address' => $session['ip'],
                'user_agent' => $session['user_agent'],
            ] : null,
            'today' => [
                'first_login_at' => $today['login_at'] ?? null,
                'last_logout_at' => $today['logout_at'] ?? null,
                'is_open' => (bool) ($today['is_checked_in'] ?? false),
                'is_late' => false,
                'working_seconds' => (int) ($today['working_seconds'] ?? 0),
                'break_seconds' => (int) ($today['break_seconds'] ?? 0),
                'on_break_since' => $onBreak,
                'sessions' => $today ? count($today['sessions']) : 0,
            ],
            'office_hours' => $settings['office_hours'],
        ],
        'leads' => $leads,
        'calls' => $calls,
        'follow_ups' => $followUps,
        'site_visits' => $visits,
        'statuses' => lead_statuses(),
        'stats' => workspace_stats($user, $leads, $callRows, $followUps, $visits),
        'attendance' => $attendance,
        'performance' => employee_performance($user, $leads),
        'server_time' => iso_dt(utc_now()),
    ]);
}

function handle_employee_attendance()
{
    $user = require_user();
    json_ok(employee_month_attendance($user, $_GET['month'] ?? gmdate('Y-m')));
}

function handle_health()
{
    try {
        db()->query('SELECT 1');
    } catch (Throwable $error) {
        json_out([
            'success' => false,
            'status' => 'error',
            'database' => 'disconnected',
            'error' => 'Database connection failed.',
            'data' => ['status' => 'error', 'mode' => 'mysql', 'database' => false],
        ], 503);
    }
    json_out([
        'success' => true,
        'status' => 'ok',
        'database' => 'connected',
        'data' => ['status' => 'ok', 'mode' => 'mysql', 'database' => true],
    ]);
}
