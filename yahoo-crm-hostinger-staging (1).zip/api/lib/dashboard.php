<?php

function handle_dashboard()
{
    $user = require_user();
    if (!in_array($user['role'], ['admin', 'team_lead'], true)) {
        throw new HttpError('Company dashboard access required.', 403);
    }
    if (empty($user['company_id'])) {
        throw new HttpError('Your account is not assigned to a company.', 403);
    }
    $companyId = (int) $user['company_id'];
    $timezone = $user['timezone'] ?: 'Asia/Kolkata';
    $today = work_date($timezone);
    $leadWhere = 'company_id = ?';
    $leadParams = [$companyId];
    $userWhere = "company_id = ? AND role IN ('employee','team_lead')";
    $userParams = [$companyId];
    if ($user['role'] === 'team_lead') {
        if (empty($user['team_id'])) {
            $userWhere .= ' AND id = ?';
            $userParams[] = (int) $user['id'];
        } else {
            $userWhere .= ' AND (id = ? OR (team_id = ? AND role = \'employee\'))';
            $userParams[] = (int) $user['id'];
            $userParams[] = (int) $user['team_id'];
        }
        $ids = db_all("SELECT id FROM users WHERE $userWhere", $userParams);
        $idList = array_map(function ($row) {
            return (int) $row['id'];
        }, $ids);
        if (!$idList) {
            $idList = [0];
        }
        $leadWhere .= ' AND owner_id IN (' . implode(',', $idList) . ')';
    }
    $people = db_all("SELECT id, full_name, role, is_active FROM users WHERE $userWhere ORDER BY full_name", $userParams);
    $activeEmployees = (int) db_one("SELECT COUNT(*) AS c FROM users WHERE $userWhere AND is_active = 1", $userParams)['c'];
    $attendanceToday = (int) db_one(
        'SELECT COUNT(*) AS c FROM attendance WHERE company_id = ? AND work_date = ?' . ($user['role'] === 'team_lead' ? ' AND user_id IN (' . implode(',', array_map(function ($p) { return (int) $p['id']; }, $people) ?: [0]) . ')' : ''),
        [$companyId, $today]
    )['c'];
    [$start, $end] = local_day_utc_bounds($today, $timezone);
    $visitIds = array_map(function ($person) {
        return (int) $person['id'];
    }, $people);
    if (!$visitIds) {
        $visitIds = [0];
    }
    $visitWhere = $user['role'] === 'team_lead'
        ? 'company_id = ? AND employee_id IN (' . implode(',', $visitIds) . ')'
        : 'company_id = ?';
    $leadsToday = (int) db_one("SELECT COUNT(*) AS c FROM leads WHERE $leadWhere AND created_at >= ? AND created_at < ?", array_merge($leadParams, [$start, $end]))['c'];
    $unassigned = $user['role'] === 'admin'
        ? (int) db_one("SELECT COUNT(*) AS c FROM leads WHERE $leadWhere AND owner_id IS NULL", $leadParams)['c']
        : 0;
    $overdue = (int) db_one(
        "SELECT COUNT(*) AS c FROM leads WHERE $leadWhere AND next_follow_up_at IS NOT NULL AND next_follow_up_at < ? AND status_id <> 4",
        array_merge($leadParams, [utc_now()])
    )['c'];
    $statusRows = db_all("SELECT status_id, COUNT(*) AS cnt FROM leads WHERE $leadWhere GROUP BY status_id", $leadParams);
    $statusMap = [];
    foreach ($statusRows as $row) {
        $statusMap[(int) $row['status_id']] = (int) $row['cnt'];
    }
    $leadsByStatus = [];
    foreach (lead_statuses() as $status) {
        $leadsByStatus[] = ['id' => $status['id'], 'name' => $status['name'], 'cnt' => $statusMap[$status['id']] ?? 0];
    }
    $trend = [];
    for ($i = 6; $i >= 0; $i--) {
        $date = (new DateTime($today))->modify('-' . $i . ' day')->format('Y-m-d');
        [$dayStart, $dayEnd] = local_day_utc_bounds($date, $timezone);
        $count = (int) db_one(
            "SELECT COUNT(*) AS c FROM leads WHERE $leadWhere AND created_at >= ? AND created_at < ?",
            array_merge($leadParams, [$dayStart, $dayEnd])
        )['c'];
        $visits = (int) db_one(
            "SELECT COUNT(*) AS c FROM site_visits WHERE $visitWhere AND scheduled_at >= ? AND scheduled_at < ?",
            [$companyId, $dayStart, $dayEnd]
        )['c'];
        $conversions = (int) db_one(
            "SELECT COUNT(*) AS c FROM leads WHERE $leadWhere AND status_id = 2 AND updated_at >= ? AND updated_at < ?",
            array_merge($leadParams, [$dayStart, $dayEnd])
        )['c'];
        $trend[] = [
            'date' => $date,
            'label' => gmdate('d M', strtotime($date)),
            'leads' => $count,
            'visits' => $visits,
            'conversions' => $conversions,
        ];
    }
    $performance = [];
    foreach ($people as $person) {
        $total = (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE owner_id = ?', [(int) $person['id']])['c'];
        $interested = (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE owner_id = ? AND status_id = 2', [(int) $person['id']])['c'];
        $notInterested = (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE owner_id = ? AND status_id = 4', [(int) $person['id']])['c'];
        $overdueTasks = (int) db_one(
            'SELECT COUNT(*) AS c FROM leads WHERE owner_id = ? AND next_follow_up_at IS NOT NULL AND next_follow_up_at < ? AND status_id <> 4',
            [(int) $person['id'], utc_now()]
        )['c'];
        $performance[] = [
            'id' => (string) $person['id'],
            'name' => $person['full_name'],
            'full_name' => $person['full_name'],
            'role' => $person['role'],
            'is_active' => (bool) $person['is_active'],
            'total_leads' => $total,
            'interested_leads' => $interested,
            'conversions' => $interested,
            'not_interested' => $notInterested,
            'interest_rate' => $total ? round(($interested / $total) * 100, 1) : 0,
            'conversion_rate' => $total ? round(($interested / $total) * 100, 1) : 0,
            'overdue_tasks' => $overdueTasks,
            'open_leads' => max(0, $total - $notInterested),
        ];
    }
    usort($performance, function ($a, $b) {
        return $b['total_leads'] <=> $a['total_leads'];
    });
    json_ok([
        'role' => $user['role'],
        'company_id' => (string) $companyId,
        'generated_at' => gmdate('c'),
        'kpis' => [
            'active_employees' => $activeEmployees,
            'attendance_today' => $attendanceToday,
            'leads_today' => $leadsToday,
            'unassigned_leads' => $unassigned,
            'unassigned_team_leads' => $unassigned,
            'overdue_followups' => $overdue,
        ],
        'leads_by_status' => $leadsByStatus,
        'trend' => $trend,
        'employee_performance' => $performance,
        'members' => $performance,
        'workload' => $performance,
        'team_conversion' => $performance,
        'metrics_definitions' => [
            'interest_rate' => 'Interested leads divided by total assigned leads.',
            'conversion_rate' => 'Interested leads divided by total assigned leads. A separate booked-conversion status is not stored.',
            'open_leads' => 'Assigned leads excluding leads marked Not interested.',
            'attendance_today' => 'Number of attendance records for the current company work date.',
        ],
    ]);
}

function report_bounds()
{
    $from = isset($_GET['from']) ? (string) $_GET['from'] : '';
    $to = isset($_GET['to']) ? (string) $_GET['to'] : '';
    if (($from !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) || ($to !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))) {
        throw new HttpError('Dates must use YYYY-MM-DD format.', 400);
    }
    if ($from !== '' && $to !== '' && $from > $to) {
        throw new HttpError('Start date cannot be after end date.', 400);
    }
    return [$from, $to];
}

function report_between($column, $from, $to, $dateOnly = false)
{
    $sql = '';
    $params = [];
    if ($from !== '') {
        $sql .= " AND $column >= ?";
        $params[] = $dateOnly ? $from : $from . ' 00:00:00';
    }
    if ($to !== '') {
        $sql .= " AND $column <= ?";
        $params[] = $dateOnly ? $to : $to . ' 23:59:59';
    }
    return [$sql, $params];
}

function handle_reports_companies()
{
    $user = require_user();
    if (!in_array($user['role'], ['super_admin', 'admin', 'team_lead'], true)) {
        throw new HttpError('You do not have permission to view company reports.', 403);
    }
    [$from, $to] = report_bounds();
    if ($user['role'] === 'super_admin') {
        $companies = db_all('SELECT * FROM companies ORDER BY name ASC');
    } else {
        if (empty($user['company_id'])) {
            throw new HttpError('Your account is not assigned to a company.', 403);
        }
        $companies = db_all('SELECT * FROM companies WHERE id = ?', [(int) $user['company_id']]);
    }
    $data = [];
    foreach ($companies as $company) {
        [$leadSql, $leadParams] = report_between('created_at', $from, $to);
        [$attendanceSql, $attendanceParams] = report_between('work_date', $from, $to, true);
        $data[] = [
            'id' => (string) $company['id'],
            'name' => $company['name'],
            'code' => $company['code'],
            'admin_name' => $company['admin_name'],
            'admin_email' => $company['admin_email'],
            'is_active' => (bool) $company['is_active'],
            'total_leads' => (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE company_id = ?' . $leadSql, array_merge([(int) $company['id']], $leadParams))['c'],
            'active_employees' => (int) db_one("SELECT COUNT(*) AS c FROM users WHERE company_id = ? AND role IN ('team_lead','employee') AND is_active = 1", [(int) $company['id']])['c'],
            'attendance_records' => (int) db_one('SELECT COUNT(*) AS c FROM attendance WHERE company_id = ?' . $attendanceSql, array_merge([(int) $company['id']], $attendanceParams))['c'],
        ];
    }
    json_ok($data);
}

function handle_report_company($companyId)
{
    $user = require_user();
    $id = int_id($companyId, 'company ID');
    if ($user['role'] === 'admin' && (int) $user['company_id'] !== $id) {
        throw new HttpError('You do not have permission to view this company.', 403);
    }
    if ($user['role'] === 'team_lead' && (int) $user['company_id'] !== $id) {
        throw new HttpError('You do not have permission to view this company.', 403);
    }
    if (!in_array($user['role'], ['super_admin', 'admin', 'team_lead'], true)) {
        throw new HttpError('You do not have permission to view company reports.', 403);
    }
    [$from, $to] = report_bounds();
    $company = db_one('SELECT * FROM companies WHERE id = ?', [$id]);
    if (!$company) {
        throw new HttpError('Company not found.', 404);
    }
    $ownerSql = '';
    $peopleSql = "company_id = ? AND role IN ('employee','team_lead')";
    $peopleParams = [$id];
    if ($user['role'] === 'team_lead') {
        if (empty($user['team_id'])) {
            $ownerSql = ' AND owner_id = ?';
            $peopleSql .= ' AND id = ?';
            $peopleParams[] = (int) $user['id'];
        } else {
            $memberIds = db_all(
                "SELECT id FROM users WHERE company_id = ? AND (id = ? OR (team_id = ? AND role = 'employee'))",
                [$id, (int) $user['id'], (int) $user['team_id']]
            );
            $idList = array_map(function ($row) {
                return (int) $row['id'];
            }, $memberIds);
            if (!$idList) {
                $idList = [(int) $user['id']];
            }
            $ownerSql = ' AND owner_id IN (' . implode(',', $idList) . ')';
            $peopleSql .= ' AND id IN (' . implode(',', $idList) . ')';
        }
    }
    [$leadSql, $leadParams] = report_between('created_at', $from, $to);
    $leadParams = array_merge([$id], $user['role'] === 'team_lead' && empty($user['team_id']) ? [(int) $user['id']] : [], $leadParams);
    $counts = db_one(
        'SELECT COUNT(*) AS total,
            SUM(owner_id IS NULL) AS unassigned,
            SUM(status_id = 1) AS new_count,
            SUM(status_id = 2) AS interested,
            SUM(status_id = 3) AS site_visit_scheduled,
            SUM(status_id = 4) AS not_interested,
            SUM(status_id = 5) AS follow_up
         FROM leads WHERE company_id = ?' . $ownerSql . $leadSql,
        $leadParams
    );
    [$dateSql, $dateParams] = report_between('created_at', $from, $to);
    [$callSql, $callParams] = report_between('started_at', $from, $to);
    $employees = db_all("SELECT id, employee_code, full_name, role FROM users WHERE $peopleSql ORDER BY full_name", $peopleParams);
    $employeeRows = [];
    [$attendanceSql, $attendanceParams] = report_between('work_date', $from, $to, true);
    foreach ($employees as $person) {
        $employeeRows[] = [
            'id' => (string) $person['id'],
            'employee_code' => $person['employee_code'],
            'full_name' => $person['full_name'],
            'role' => $person['role'],
            'total_leads' => (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE owner_id = ?' . $dateSql, array_merge([(int) $person['id']], $dateParams))['c'],
            'interested' => (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE owner_id = ?' . $dateSql . ' AND status_id = 2', array_merge([(int) $person['id']], $dateParams))['c'],
            'site_visit_scheduled' => (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE owner_id = ?' . $dateSql . ' AND status_id = 3', array_merge([(int) $person['id']], $dateParams))['c'],
            'calls' => (int) db_one('SELECT COUNT(*) AS c FROM lead_calls WHERE employee_id = ?' . $callSql, array_merge([(int) $person['id']], $callParams))['c'],
            'attendance' => report_person_attendance((int) $person['id'], $attendanceSql, $attendanceParams),
        ];
    }
    $scopeParams = [$id];
    if ($user['role'] === 'team_lead' && empty($user['team_id'])) {
        $scopeParams[] = (int) $user['id'];
    }
    $points = [];
    $trendStart = $from !== '' ? $from : gmdate('Y-m-d', strtotime('-6 day'));
    $trendEnd = $to !== '' ? $to : gmdate('Y-m-d');
    $cursor = new DateTime($trendStart);
    $last = new DateTime($trendEnd);
    $guard = 0;
    while ($cursor <= $last && $guard < 370) {
        $date = $cursor->format('Y-m-d');
        $points[] = [
            'date' => $date,
            'total' => (int) db_one(
                'SELECT COUNT(*) AS c FROM leads WHERE company_id = ?' . $ownerSql . ' AND created_at >= ? AND created_at <= ?',
                array_merge($scopeParams, [$date . ' 00:00:00', $date . ' 23:59:59'])
            )['c'],
        ];
        $cursor->modify('+1 day');
        $guard++;
    }
    $attendanceWhere = 'company_id = ?' . ($user['role'] === 'team_lead' && $ownerSql !== '' ? str_replace('owner_id', 'user_id', $ownerSql) : '') . $attendanceSql;
    $attendanceBind = array_merge([$id], $user['role'] === 'team_lead' && empty($user['team_id']) ? [(int) $user['id']] : ($user['role'] === 'team_lead' ? [] : []), $attendanceParams);
    if ($user['role'] === 'team_lead' && !empty($user['team_id'])) {
        $attendanceBind = array_merge([$id], $attendanceParams);
        $attendanceWhere = 'company_id = ?' . str_replace('owner_id', 'user_id', $ownerSql) . $attendanceSql;
    }
    $attendance = db_all('SELECT * FROM attendance WHERE ' . $attendanceWhere, $attendanceBind);
    $checkedOut = 0;
    $checkedIn = 0;
    $workingSeconds = 0;
    $breakSeconds = 0;
    foreach ($attendance as $record) {
        if ($record['logout_at']) {
            $checkedOut++;
        } else {
            $checkedIn++;
        }
        $time = attendance_durations(attendance_sessions($record));
        $workingSeconds += $time['working_seconds'];
        $breakSeconds += $time['break_seconds'];
    }
    json_ok([
        'company' => [
            'id' => (string) $company['id'],
            'name' => $company['name'],
            'code' => $company['code'],
            'admin_name' => $company['admin_name'],
            'admin_email' => $company['admin_email'],
            'phone' => $company['phone'],
            'is_active' => (bool) $company['is_active'],
        ],
        'period' => ['from' => $_GET['from'] ?? null, 'to' => $_GET['to'] ?? null],
        'leads' => [
            'total' => (int) $counts['total'],
            'unassigned' => (int) $counts['unassigned'],
            'new' => (int) $counts['new_count'],
            'interested' => (int) $counts['interested'],
            'site_visit_scheduled' => (int) $counts['site_visit_scheduled'],
            'not_interested' => (int) $counts['not_interested'],
            'follow_up' => (int) $counts['follow_up'],
        ],
        'statuses' => lead_statuses(),
        'lead_trend' => [
            'interval' => 'day',
            'from' => $trendStart,
            'to' => $trendEnd,
            'points' => $points,
        ],
        'employees' => $employeeRows,
        'attendance' => [
            'total_records' => count($attendance),
            'attendance_days' => count($attendance),
            'checked_out' => $checkedOut,
            'currently_checked_in' => $checkedIn,
            'total_working_seconds' => $workingSeconds,
            'total_break_seconds' => $breakSeconds,
        ],
    ]);
}

function report_person_attendance($userId, $attendanceSql, $attendanceParams)
{
    $rows = db_all('SELECT * FROM attendance WHERE user_id = ?' . $attendanceSql, array_merge([$userId], $attendanceParams));
    $working = 0;
    foreach ($rows as $record) {
        $working += attendance_durations(attendance_sessions($record))['working_seconds'];
    }
    return [
        'attendance_days' => count($rows),
        'total_working_seconds' => $working,
    ];
}

function handle_my_performance()
{
    $user = require_user();
    if (!in_array($user['role'], ['team_lead', 'employee'], true)) {
        throw new HttpError('Personal performance is available to Team Leads and Employees.', 403);
    }
    $total = (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE owner_id = ?', [(int) $user['id']])['c'];
    $interested = (int) db_one('SELECT COUNT(*) AS c FROM leads WHERE owner_id = ? AND status_id = 2', [(int) $user['id']])['c'];
    $calls = (int) db_one('SELECT COUNT(*) AS c FROM lead_calls WHERE employee_id = ?', [(int) $user['id']])['c'];
    json_ok([
        'full_name' => $user['full_name'],
        'total_leads' => $total,
        'interested' => $interested,
        'calls' => $calls,
        'interest_rate' => $total ? round(($interested / $total) * 100, 1) : 0,
    ]);
}
