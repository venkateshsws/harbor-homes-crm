<?php

function attendance_sessions($record)
{
    $sessions = json_decode($record['sessions_json'] ?? '[]', true);
    if (!is_array($sessions) || !$sessions) {
        return [[
            'login_at' => $record['login_at'],
            'logout_at' => $record['logout_at'],
            'breaks' => [],
        ]];
    }
    return $sessions;
}

function attendance_durations($sessions)
{
    $sessionSeconds = 0;
    $breakSeconds = 0;
    $now = time();
    foreach ($sessions as $session) {
        if (empty($session['login_at'])) {
            continue;
        }
        $start = strtotime($session['login_at'] . ' UTC');
        $end = !empty($session['logout_at']) ? strtotime($session['logout_at'] . ' UTC') : $now;
        $sessionSeconds += max(0, $end - $start);
        foreach ($session['breaks'] ?? [] as $item) {
            if (empty($item['start_at'])) {
                continue;
            }
            $bStart = strtotime($item['start_at'] . ' UTC');
            $bEnd = !empty($item['end_at']) ? strtotime($item['end_at'] . ' UTC') : $end;
            $breakSeconds += max(0, $bEnd - $bStart);
        }
    }
    return [
        'session_seconds' => $sessionSeconds,
        'break_seconds' => $breakSeconds,
        'working_seconds' => max(0, $sessionSeconds - $breakSeconds),
    ];
}

function serialize_attendance($record)
{
    $sessions = attendance_sessions($record);
    $active = null;
    foreach ($sessions as $session) {
        if (empty($session['logout_at'])) {
            $active = $session;
            break;
        }
    }
    $first = $sessions[0] ?? null;
    $latest = $sessions[count($sessions) - 1] ?? null;
    $time = attendance_durations($sessions);
    return [
        'id' => (string) $record['id'],
        'employee_id' => (string) $record['user_id'],
        'employee_code' => $record['employee_code'],
        'full_name' => $record['full_name'],
        'work_date' => $record['work_date'],
        'login_at' => iso_dt($first['login_at'] ?? $record['login_at']),
        'logout_at' => $active ? null : iso_dt($latest['logout_at'] ?? $record['logout_at']),
        'sessions' => array_map(function ($session) {
            return [
                'login_at' => iso_dt($session['login_at'] ?? null),
                'logout_at' => iso_dt($session['logout_at'] ?? null),
            ];
        }, $sessions),
        'breaks' => array_map(function ($item) {
            return [
                'start_at' => iso_dt($item['start_at'] ?? null),
                'end_at' => iso_dt($item['end_at'] ?? null),
            ];
        }, $active['breaks'] ?? []),
        'is_checked_in' => (bool) $active,
        'working_seconds' => $time['working_seconds'],
        'session_seconds' => $time['session_seconds'],
        'break_seconds' => $time['break_seconds'],
        'is_late' => false,
        'status' => $active ? 'present' : 'checked_out',
    ];
}

function save_attendance_sessions($record, $sessions, $status)
{
    $first = $sessions[0];
    $latest = $sessions[count($sessions) - 1];
    $active = null;
    foreach ($sessions as $session) {
        if (empty($session['logout_at'])) {
            $active = $session;
        }
    }
    db_exec(
        'UPDATE attendance SET sessions_json = ?, login_at = ?, logout_at = ?, status = ? WHERE id = ?',
        [
            json_encode($sessions),
            sql_dt($first['login_at']),
            $active ? null : sql_dt($latest['logout_at']),
            $status,
            (int) $record['id'],
        ]
    );
}

function today_attendance($user)
{
    $date = work_date($user['timezone'] ?? 'Asia/Kolkata');
    $record = db_one('SELECT * FROM attendance WHERE user_id = ? AND work_date = ?', [(int) $user['id'], $date]);
    return [$record, $date];
}

function handle_check_in()
{
    $user = require_user();
    [$record, $date] = today_attendance($user);
    $now = utc_now();
    if ($record) {
        $sessions = attendance_sessions($record);
        foreach ($sessions as $session) {
            if (empty($session['logout_at'])) {
                throw new HttpError('You are already checked in.', 409);
            }
        }
        $sessions[] = ['login_at' => $now, 'logout_at' => null, 'breaks' => []];
        save_attendance_sessions($record, $sessions, 'present');
        json_ok(serialize_attendance(db_one('SELECT * FROM attendance WHERE id = ?', [(int) $record['id']])));
    }
    $id = db_insert(
        'INSERT INTO attendance (user_id, company_id, employee_code, full_name, work_date, timezone, login_at, logout_at, sessions_json, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, NULL, ?, \'present\', ?, ?)',
        [
            (int) $user['id'],
            $user['company_id'] ?: null,
            $user['employee_code'],
            $user['full_name'],
            $date,
            $user['timezone'] ?? 'Asia/Kolkata',
            $now,
            json_encode([['login_at' => $now, 'logout_at' => null, 'breaks' => []]]),
            utc_now(),
            utc_now(),
        ]
    );
    json_out(['success' => true, 'data' => serialize_attendance(db_one('SELECT * FROM attendance WHERE id = ?', [$id]))], 201);
}

function handle_check_out()
{
    $user = require_user();
    [$record] = today_attendance($user);
    if (!$record) {
        throw new HttpError('Check in before checking out.', 409);
    }
    $sessions = attendance_sessions($record);
    $found = false;
    $now = utc_now();
    foreach ($sessions as &$session) {
        if (empty($session['logout_at'])) {
            foreach ($session['breaks'] as &$item) {
                if (empty($item['end_at'])) {
                    $item['end_at'] = $now;
                }
            }
            unset($item);
            $session['logout_at'] = $now;
            $found = true;
        }
    }
    unset($session);
    if (!$found) {
        throw new HttpError('No active check-in found. Please check in first.', 409);
    }
    save_attendance_sessions($record, $sessions, 'checked_out');
    json_ok(serialize_attendance(db_one('SELECT * FROM attendance WHERE id = ?', [(int) $record['id']])));
}

function handle_attendance_today()
{
    $user = require_user();
    [$record] = today_attendance($user);
    json_ok($record ? serialize_attendance($record) : null);
}

function handle_break_start()
{
    $user = require_user();
    [$record] = today_attendance($user);
    if (!$record) {
        throw new HttpError('Check in before starting a break.', 409);
    }
    $sessions = attendance_sessions($record);
    $found = false;
    foreach ($sessions as &$session) {
        if (!empty($session['logout_at'])) {
            continue;
        }
        foreach ($session['breaks'] ?? [] as $item) {
            if (empty($item['end_at'])) {
                throw new HttpError('A break is already in progress.', 409);
            }
        }
        $session['breaks'][] = ['start_at' => utc_now(), 'end_at' => null];
        $found = true;
    }
    unset($session);
    if (!$found) {
        throw new HttpError('Check in before starting a break.', 409);
    }
    save_attendance_sessions($record, $sessions, 'present');
    json_ok(serialize_attendance(db_one('SELECT * FROM attendance WHERE id = ?', [(int) $record['id']])));
}

function handle_break_end()
{
    $user = require_user();
    [$record] = today_attendance($user);
    if (!$record) {
        throw new HttpError('No active attendance session was found.', 409);
    }
    $sessions = attendance_sessions($record);
    $found = false;
    foreach ($sessions as &$session) {
        if (!empty($session['logout_at'])) {
            continue;
        }
        foreach ($session['breaks'] as &$item) {
            if (empty($item['end_at'])) {
                $item['end_at'] = utc_now();
                $found = true;
                break;
            }
        }
        unset($item);
    }
    unset($session);
    if (!$found) {
        throw new HttpError('There is no active break.', 409);
    }
    save_attendance_sessions($record, $sessions, 'present');
    json_ok(serialize_attendance(db_one('SELECT * FROM attendance WHERE id = ?', [(int) $record['id']])));
}

function attendance_visible($user)
{
    if ($user['role'] === 'super_admin') {
        return ['1 = 1', []];
    }
    if ($user['role'] === 'admin' && $user['company_id']) {
        return ['company_id = ?', [(int) $user['company_id']]];
    }
    if ($user['role'] === 'team_lead' && $user['company_id'] && $user['team_id']) {
        return [
            'company_id = ? AND user_id IN (SELECT id FROM users WHERE id = ? OR team_id = ?)',
            [(int) $user['company_id'], (int) $user['id'], (int) $user['team_id']],
        ];
    }
    return ['user_id = ?', [(int) $user['id']]];
}

function handle_attendance_list()
{
    $user = require_user();
    [$where, $params] = attendance_visible($user);
    $rows = db_all("SELECT * FROM attendance WHERE $where ORDER BY work_date DESC, login_at DESC LIMIT 500", $params);
    json_ok(array_map('serialize_attendance', $rows));
}

function handle_attendance_summary()
{
    $user = require_user();
    [$where, $params] = attendance_visible($user);
    $rows = db_all("SELECT * FROM attendance WHERE $where ORDER BY work_date DESC LIMIT 500", $params);
    $grouped = [];
    foreach ($rows as $record) {
        $id = (string) $record['user_id'];
        if (!isset($grouped[$id])) {
            $grouped[$id] = [
                'id' => $id,
                'full_name' => $record['full_name'],
                'present_days' => 0,
                'total_working_seconds' => 0,
                'total_session_seconds' => 0,
                'total_break_seconds' => 0,
                'late_count' => 0,
                'missing_logout_count' => 0,
            ];
        }
        $time = attendance_durations(attendance_sessions($record));
        $grouped[$id]['present_days']++;
        $grouped[$id]['total_working_seconds'] += $time['working_seconds'];
        $grouped[$id]['total_session_seconds'] += $time['session_seconds'];
        $grouped[$id]['total_break_seconds'] += $time['break_seconds'];
        $sessions = attendance_sessions($record);
        foreach ($sessions as $session) {
            if (empty($session['logout_at'])) {
                $grouped[$id]['missing_logout_count']++;
                break;
            }
        }
    }
    json_ok([
        'employees' => array_values($grouped),
        'note' => 'Working duration excludes recorded breaks. It measures session time, not verified productive time.',
    ]);
}
