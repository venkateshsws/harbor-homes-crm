<?php

const SESSION_COOKIE = 'hh_session';

function password_problem($password)
{
    if (!is_string($password) || strlen($password) < 10) {
        return 'Password must be at least 10 characters.';
    }
    if (strlen($password) > 200) {
        return 'Password must be at most 200 characters.';
    }
    return null;
}

function hash_password($password)
{
    return password_hash($password, PASSWORD_DEFAULT);
}

function verify_password($password, $stored)
{
    if (!is_string($stored) || $stored === '') {
        password_verify($password, '$2y$10$usesomesillystringfore7hnbRJHxXVLeakoG8K30oukPsA.ztMG');
        return false;
    }
    if (str_starts_with($stored, '$2y$') || str_starts_with($stored, '$2a$') || str_starts_with($stored, '$argon2')) {
        return password_verify($password, $stored);
    }
    return false;
}

function random_token($bytes = 32)
{
    return rtrim(strtr(base64_encode(random_bytes($bytes)), '+/', '-_'), '=');
}

function hash_token($token)
{
    return hash('sha256', $token);
}

function read_cookie($name)
{
    $value = $_COOKIE[$name] ?? '';
    return is_string($value) ? $value : '';
}

function cookie_secure()
{
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        return true;
    }
    return isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https';
}

function set_session_cookie($token, $ttl)
{
    setcookie(SESSION_COOKIE, $token, [
        'expires' => time() + $ttl,
        'path' => '/',
        'secure' => cookie_secure(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function clear_session_cookie()
{
    setcookie(SESSION_COOKIE, '', [
        'expires' => time() - 3600,
        'path' => '/',
        'secure' => cookie_secure(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function safe_equal($a, $b)
{
    return hash_equals((string) $a, (string) $b);
}

function &auth_state()
{
    static $state = ['user' => null, 'session' => null];
    return $state;
}

function current_user()
{
    return auth_state()['user'];
}

function current_session()
{
    return auth_state()['session'];
}

function load_session()
{
    $state = &auth_state();
    $token = read_cookie(SESSION_COOKIE);
    if ($token === '') {
        return;
    }
    $session = db_one(
        'SELECT * FROM sessions WHERE token_hash = ? AND expires_at > ?',
        [hash_token($token), utc_now()]
    );
    if (!$session) {
        return;
    }
    $user = db_one('SELECT * FROM users WHERE id = ?', [(int) $session['user_id']]);
    if (!$user || !(int) $user['is_active']) {
        db_exec('DELETE FROM sessions WHERE id = ?', [(int) $session['id']]);
        return;
    }
    $state['session'] = $session;
    $state['user'] = $user;
}

function verify_csrf()
{
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if (in_array($method, ['GET', 'HEAD', 'OPTIONS'], true)) {
        return;
    }
    $path = api_path();
    if ($path === '/auth/login') {
        return;
    }
    $session = current_session();
    if (!$session) {
        return;
    }
    $header = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!safe_equal($header, $session['csrf_token'])) {
        throw new HttpError('Invalid or missing CSRF token. Refresh the page and try again.', 403);
    }
}

function require_user()
{
    $user = current_user();
    if (!$user) {
        throw new HttpError('Sign in required.', 401);
    }
    return $user;
}

function require_role(...$roles)
{
    $user = require_user();
    if (!in_array($user['role'], $roles, true)) {
        throw new HttpError('You do not have permission to do this.', 403);
    }
    return $user;
}

function format_user_row($user, $company = null)
{
    if ($company === null && !empty($user['company_id'])) {
        $company = db_one('SELECT id, name, code FROM companies WHERE id = ?', [(int) $user['company_id']]);
    }
    return [
        'id' => (string) $user['id'],
        'employee_code' => $user['employee_code'],
        'email' => $user['email'],
        'full_name' => $user['full_name'],
        'phone' => $user['phone'] ?? '',
        'role' => $user['role'],
        'role_name' => role_name($user['role']),
        'company_id' => $user['company_id'] ? (string) $user['company_id'] : null,
        'company_name' => $company['name'] ?? 'Unassigned',
        'company_code' => $company['code'] ?? '',
        'team_id' => $user['team_id'] ? (string) $user['team_id'] : null,
        'specialization' => $user['specialization'] ?? '',
        'assignment_weight' => (int) $user['assignment_weight'],
        'max_open_leads' => (int) $user['max_open_leads'],
        'is_assignment_eligible' => (bool) $user['is_assignment_eligible'],
        'is_active' => (bool) $user['is_active'],
        'last_login_at' => iso_dt($user['last_login_at'] ?? null),
        'timezone' => $user['timezone'] ?? 'Asia/Kolkata',
        'created_at' => iso_dt($user['created_at'] ?? null),
        'updated_at' => iso_dt($user['updated_at'] ?? null),
    ];
}

function session_user($user)
{
    $row = format_user_row($user);
    unset($row['created_at'], $row['updated_at']);
    return $row;
}

function handle_login()
{
    rate_limit('login', 10, 15 * 60, 'Too many sign-in attempts. Try again in 15 minutes.');
    $body = request_data();
    $identifier = isset($body['identifier']) ? trim((string) $body['identifier']) : '';
    $password = isset($body['password']) ? (string) $body['password'] : '';
    if ($identifier === '' || $password === '') {
        throw new HttpError('Enter your email or employee ID and password.', 400);
    }
    $user = db_one(
        'SELECT * FROM users WHERE email = ? OR employee_code = ?',
        [strtolower($identifier), strtoupper($identifier)]
    );
    $valid = verify_password($password, $user['password_hash'] ?? '');
    if (!$user || !$valid) {
        throw new HttpError('Invalid email, employee ID, or password.', 401);
    }
    if (!(int) $user['is_active']) {
        throw new HttpError('This account has been deactivated. Contact your administrator.', 403);
    }
    $existing = current_session();
    if ($existing) {
        db_exec('DELETE FROM sessions WHERE id = ?', [(int) $existing['id']]);
    }
    $config = cfg();
    $hours = (int) ($config['session_ttl_hours'] ?? 12);
    if ($hours < 1) {
        $hours = 12;
    }
    $ttl = $hours * 3600;
    $token = random_token();
    $csrf = random_token(24);
    db_insert(
        'INSERT INTO sessions (token_hash, user_id, csrf_token, expires_at, ip, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [
            hash_token($token),
            (int) $user['id'],
            $csrf,
            gmdate('Y-m-d H:i:s', time() + $ttl),
            client_ip(),
            substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 300),
            utc_now(),
        ]
    );
    db_exec('UPDATE users SET last_login_at = ? WHERE id = ?', [utc_now(), (int) $user['id']]);
    $user['last_login_at'] = utc_now();
    set_session_cookie($token, $ttl);
    json_ok(['user' => session_user($user), 'csrf_token' => $csrf]);
}

function handle_me()
{
    $user = require_user();
    $session = current_session();
    json_ok(['user' => session_user($user), 'csrf_token' => $session['csrf_token']]);
}

function handle_logout()
{
    $session = current_session();
    if ($session) {
        db_exec('DELETE FROM sessions WHERE id = ?', [(int) $session['id']]);
    }
    clear_session_cookie();
    json_ok([]);
}

function handle_change_password()
{
    $user = require_user();
    $body = request_data();
    $current = isset($body['current_password']) ? (string) $body['current_password'] : '';
    $next = isset($body['new_password']) ? (string) $body['new_password'] : '';
    if ($current === '' || $next === '') {
        throw new HttpError('Enter your current password and a new password.', 400);
    }
    $problem = password_problem($next);
    if ($problem) {
        throw new HttpError(preg_replace('/^Password/', 'New password', $problem), 400);
    }
    if ($next === $current) {
        throw new HttpError('New password must be different from the current password.', 400);
    }
    $fresh = db_one('SELECT * FROM users WHERE id = ?', [(int) $user['id']]);
    if (!$fresh || !(int) $fresh['is_active']) {
        throw new HttpError('This account has been deactivated. Contact your administrator.', 403);
    }
    if (!verify_password($current, $fresh['password_hash'])) {
        throw new HttpError('Current password is incorrect.', 400);
    }
    db_exec('UPDATE users SET password_hash = ? WHERE id = ?', [hash_password($next), (int) $user['id']]);
    db_exec('DELETE FROM sessions WHERE user_id = ?', [(int) $user['id']]);
    clear_session_cookie();
    audit_write('change_password', 'user', $user['id']);
    json_ok([]);
}
