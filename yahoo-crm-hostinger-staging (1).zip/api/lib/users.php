<?php

function user_list_filter($user)
{
    $where = [];
    $params = [];
    $companyId = $_GET['company_id'] ?? null;
    $role = $_GET['role'] ?? null;
    $status = $_GET['status'] ?? null;
    $search = trim((string) ($_GET['search'] ?? ''));

    if ($user['role'] === 'super_admin') {
        if ($companyId !== null && $companyId !== '') {
            $id = int_id($companyId, 'company ID');
            if (!db_one('SELECT id FROM companies WHERE id = ?', [$id])) {
                throw new HttpError('Company not found.', 404);
            }
            $where[] = 'u.company_id = ?';
            $params[] = $id;
        }
        if ($role) {
            if (!in_array($role, ['super_admin', 'admin', 'team_lead', 'employee'], true)) {
                throw new HttpError('Invalid user role.', 400);
            }
            $where[] = 'u.role = ?';
            $params[] = $role;
        }
        if ($status) {
            if ($status === 'active') {
                $where[] = 'u.is_active = 1';
            } elseif ($status === 'inactive') {
                $where[] = 'u.is_active = 0';
            } else {
                throw new HttpError('Invalid status filter.', 400);
            }
        }
    } elseif ($user['role'] === 'admin') {
        if (!$user['company_id']) {
            throw new HttpError('Your admin account is not assigned to a company.', 403);
        }
        $where[] = 'u.company_id = ?';
        $params[] = (int) $user['company_id'];
        $where[] = "u.role = 'employee'";
    } elseif ($user['role'] === 'team_lead') {
        if (!$user['company_id'] || !$user['team_id']) {
            return ['1 = 0', []];
        }
        $where[] = 'u.company_id = ? AND u.team_id = ? AND u.role = \'employee\'';
        $params[] = (int) $user['company_id'];
        $params[] = (int) $user['team_id'];
    } else {
        throw new HttpError('You do not have permission to view users.', 403);
    }

    if ($search !== '') {
        $like = '%' . $search . '%';
        $where[] = '(u.full_name LIKE ? OR u.email LIKE ? OR u.employee_code LIKE ? OR u.phone LIKE ?)';
        array_push($params, $like, $like, $like, $like);
    }
    $sql = $where ? implode(' AND ', $where) : '1 = 1';
    return [$sql, $params];
}

function handle_users_list()
{
    $user = require_user();
    [$sql, $params] = user_list_filter($user);
    $rows = db_all(
        "SELECT u.* FROM users u WHERE $sql ORDER BY u.created_at DESC",
        $params
    );
    $formatted = array_map(function ($row) {
        return format_user_row($row);
    }, $rows);
    json_out([
        'success' => true,
        'users' => $formatted,
        'data' => ['users' => $formatted],
        'total' => count($formatted),
    ]);
}

function assert_can_view_user($actor, $target)
{
    if ($actor['role'] === 'super_admin') {
        return;
    }
    if ((int) $actor['id'] === (int) $target['id']) {
        return;
    }
    if ($actor['role'] === 'admin' && (int) $actor['company_id'] === (int) $target['company_id'] && $target['role'] === 'employee') {
        return;
    }
    if ($actor['role'] === 'team_lead' && (int) $actor['team_id'] === (int) $target['team_id'] && $target['role'] === 'employee') {
        return;
    }
    throw new HttpError('You do not have permission to view this user.', 403);
}

function handle_user_get($id)
{
    $actor = require_user();
    $userId = int_id($id, 'user ID');
    $target = db_one('SELECT * FROM users WHERE id = ?', [$userId]);
    if (!$target) {
        throw new HttpError('User not found.', 404);
    }
    assert_can_view_user($actor, $target);
    json_ok(format_user_row($target));
}

function handle_user_create()
{
    require_role('super_admin');
    $body = request_data();
    $code = strtoupper(trim((string) ($body['employee_code'] ?? '')));
    $email = strtolower(trim((string) ($body['email'] ?? '')));
    $name = trim((string) ($body['full_name'] ?? ''));
    $phone = trim((string) ($body['phone'] ?? ''));
    $password = (string) ($body['password'] ?? '');
    $role = (string) ($body['role'] ?? 'employee');
    if (!in_array($role, ['team_lead', 'employee'], true)) {
        $role = 'employee';
    }
    if ($code === '' || $email === '' || $name === '' || $password === '') {
        throw new HttpError('Employee code, email, full name and password are required.', 400);
    }
    if (!email_ok($email)) {
        throw new HttpError('Please enter a valid email address.', 400);
    }
    if (strlen($password) < 8) {
        throw new HttpError('Password must contain at least 8 characters.', 400);
    }
    $companyId = int_id($body['company_id'] ?? null, 'company ID');
    $company = db_one('SELECT * FROM companies WHERE id = ?', [$companyId]);
    if (!$company) {
        throw new HttpError('The selected company does not exist.', 404);
    }
    if (!(int) $company['is_active']) {
        throw new HttpError('Cannot add employees to an inactive company.', 400);
    }
    $teamId = null;
    if (!empty($body['team_id'])) {
        $teamId = int_id($body['team_id'], 'team ID');
        $team = db_one('SELECT id FROM teams WHERE id = ? AND company_id = ?', [$teamId, $companyId]);
        if (!$team) {
            throw new HttpError('Invalid team ID.', 400);
        }
    }
    $weight = (int) ($body['assignment_weight'] ?? 1);
    $maxOpen = (int) ($body['max_open_leads'] ?? 50);
    if ($weight < 1 || $maxOpen < 1) {
        throw new HttpError('Assignment weight and maximum open leads must be valid positive numbers.', 400);
    }
    if (db_one('SELECT id FROM users WHERE email = ? OR employee_code = ?', [$email, $code])) {
        throw new HttpError('An account with this employee code or email already exists.', 409);
    }
    $id = db_insert(
        'INSERT INTO users (employee_code, email, full_name, phone, role, company_id, team_id, specialization, assignment_weight, max_open_leads, is_assignment_eligible, is_active, password_hash, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, ?, ?, ?)',
        [
            $code,
            $email,
            $name,
            $phone !== '' ? $phone : null,
            $role,
            $companyId,
            $teamId,
            trim((string) ($body['specialization'] ?? '')),
            $weight,
            $maxOpen,
            hash_password($password),
            utc_now(),
            utc_now(),
        ]
    );
    if ($role === 'team_lead' && $teamId) {
        db_exec('UPDATE teams SET team_lead_id = ? WHERE id = ?', [$id, $teamId]);
    }
    audit_write('create_user', 'user', $id);
    $created = db_one('SELECT * FROM users WHERE id = ?', [$id]);
    json_out([
        'success' => true,
        'message' => 'Employee account created successfully.',
        'user' => format_user_row($created),
    ], 201);
}

function handle_user_update($id)
{
    $actor = require_user();
    $userId = int_id($id, 'employee ID');
    $target = db_one('SELECT * FROM users WHERE id = ?', [$userId]);
    if (!$target) {
        throw new HttpError('User not found.', 404);
    }
    $self = (int) $actor['id'] === $userId;
    $super = $actor['role'] === 'super_admin';
    $admin = $actor['role'] === 'admin' && (int) $actor['company_id'] === (int) $target['company_id'];
    if (!$self && !$super && !$admin) {
        throw new HttpError('You do not have permission to edit this user.', 403);
    }
    $body = request_data();
    $sets = [];
    $params = [];
    $fields = $self && !$super && !$admin
        ? ['full_name', 'phone']
        : ['employee_code', 'full_name', 'email', 'phone', 'team_id', 'specialization', 'assignment_weight', 'max_open_leads', 'is_assignment_eligible'];
    foreach ($fields as $field) {
        if (!array_key_exists($field, $body)) {
            continue;
        }
        $value = $body[$field];
        if ($field === 'email') {
            $value = strtolower(trim((string) $value));
            if (!email_ok($value)) {
                throw new HttpError('Please enter a valid email address.', 400);
            }
            $taken = db_one('SELECT id FROM users WHERE email = ? AND id <> ?', [$value, $userId]);
            if ($taken) {
                throw new HttpError('This email is already used by another user account.', 409);
            }
        } elseif ($field === 'employee_code') {
            $value = strtoupper(trim((string) $value));
            if ($value === '') {
                throw new HttpError('Employee code is required.', 400);
            }
            $taken = db_one('SELECT id FROM users WHERE employee_code = ? AND id <> ?', [$value, $userId]);
            if ($taken) {
                throw new HttpError('This employee code is already in use.', 409);
            }
        } elseif ($field === 'team_id') {
            $value = $value === '' || $value === null ? null : int_id($value, 'team ID');
        } elseif ($field === 'is_assignment_eligible') {
            $value = $value ? 1 : 0;
        } elseif (in_array($field, ['assignment_weight', 'max_open_leads'], true)) {
            $value = (int) $value;
            if ($value < 1) {
                throw new HttpError('Assignment weight and maximum open leads must be valid positive numbers.', 400);
            }
        } else {
            $value = trim((string) $value);
        }
        $sets[] = $field . ' = ?';
        $params[] = $value;
    }
    if ($sets) {
        $params[] = $userId;
        db_exec('UPDATE users SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
    }
    audit_write('update_user', 'user', $userId);
    $updated = db_one('SELECT * FROM users WHERE id = ?', [$userId]);
    json_ok(format_user_row($updated));
}

function handle_user_status($id)
{
    $actor = require_user();
    if (!in_array($actor['role'], ['super_admin', 'admin'], true)) {
        throw new HttpError('You do not have permission to change account status.', 403);
    }
    $userId = int_id($id, 'user ID');
    $body = request_data();
    if (!array_key_exists('is_active', $body)) {
        throw new HttpError('is_active is required.', 400);
    }
    $active = filter_var($body['is_active'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    if ($active === null) {
        throw new HttpError('is_active must be true or false.', 400);
    }
    $target = db_one('SELECT * FROM users WHERE id = ?', [$userId]);
    if (!$target) {
        throw new HttpError('User not found.', 404);
    }
    if ($actor['role'] === 'admin' && ((int) $actor['company_id'] !== (int) $target['company_id'] || $target['role'] !== 'employee')) {
        throw new HttpError('You do not have permission to change this account.', 403);
    }
    if ((int) $actor['id'] === $userId) {
        throw new HttpError('You cannot deactivate your own account.', 400);
    }
    db_exec('UPDATE users SET is_active = ? WHERE id = ?', [$active ? 1 : 0, $userId]);
    if (!$active) {
        db_exec('DELETE FROM sessions WHERE user_id = ?', [$userId]);
    }
    audit_write($active ? 'activate_user' : 'deactivate_user', 'user', $userId);
    json_ok(['id' => (string) $userId, 'is_active' => $active]);
}
