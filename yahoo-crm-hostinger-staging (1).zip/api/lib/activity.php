<?php

function call_outcomes()
{
    return ['answered', 'interested', 'callback_requested', 'no_answer', 'busy', 'switched_off', 'not_interested', 'invalid_number', 'other'];
}

function activity_scope($user, $alias)
{
    if ($user['role'] === 'super_admin') {
        return ['1 = 1', []];
    }
    if (empty($user['company_id'])) {
        throw new HttpError('Your account is not assigned to a valid company.', 403);
    }
    if ($user['role'] === 'admin') {
        return ["$alias.company_id = ?", [(int) $user['company_id']]];
    }
    if ($user['role'] === 'employee') {
        return ["$alias.company_id = ? AND $alias.employee_id = ?", [(int) $user['company_id'], (int) $user['id']]];
    }
    if (empty($user['team_id'])) {
        return ['1 = 0', []];
    }
    return [
        "$alias.company_id = ? AND ($alias.employee_id = ? OR $alias.employee_id IN (SELECT id FROM users WHERE team_id = ? AND role = 'employee'))",
        [(int) $user['company_id'], (int) $user['id'], (int) $user['team_id']],
    ];
}

function find_visible_lead_for_activity($user, $leadId)
{
    $lead = fetch_lead($leadId);
    if (!$lead) {
        throw new HttpError('Assigned lead not found.', 404);
    }
    assert_lead_visible($user, $lead);
    return $lead;
}

function shape_call($call)
{
    return [
        'id' => (string) $call['id'],
        'lead_id' => (string) $call['lead_id'],
        'lead_name' => $call['lead_name'] ?? '',
        'mobile' => $call['mobile'] ?? '',
        'employee_id' => (string) $call['employee_id'],
        'employee_name' => $call['employee_name'] ?? '',
        'outcome' => $call['outcome'],
        'notes' => $call['notes'] ?? '',
        'initiated_at' => iso_dt($call['started_at']),
        'started_at' => iso_dt($call['started_at']),
        'ended_at' => iso_dt($call['ended_at']),
        'duration_seconds' => (int) $call['duration_seconds'],
        'status' => $call['status'],
    ];
}

function handle_calls_create()
{
    $user = require_user();
    $body = request_data();
    $outcome = (string) ($body['outcome'] ?? '');
    if (empty($body['lead_id']) || !in_array($outcome, call_outcomes(), true)) {
        throw new HttpError('Valid lead_id and call outcome are required.', 400);
    }
    $due = null;
    if (!empty($body['next_follow_up_at'])) {
        $due = sql_dt($body['next_follow_up_at']);
    }
    $lead = find_visible_lead_for_activity($user, int_id($body['lead_id'], 'lead ID'));
    $now = utc_now();
    $id = db_insert(
        'INSERT INTO lead_calls (company_id, lead_id, employee_id, started_at, ended_at, duration_seconds, outcome, notes, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, 0, ?, ?, \'completed\', ?, ?)',
        [(int) $lead['company_id'], (int) $lead['id'], (int) $user['id'], $now, $now, $outcome, trim((string) ($body['notes'] ?? '')), $now, $now]
    );
    if ($due) {
        db_exec('UPDATE leads SET next_follow_up_at = ? WHERE id = ?', [$due, (int) $lead['id']]);
        db_insert(
            'INSERT INTO follow_ups (company_id, lead_id, employee_id, created_by, title, task_type, priority, due_at, status, notes, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, \'call\', \'medium\', ?, \'pending\', ?, ?, ?)',
            [(int) $lead['company_id'], (int) $lead['id'], (int) ($lead['owner_id'] ?: $user['id']), (int) $user['id'], 'Follow up ' . $lead['full_name'], $due, trim((string) ($body['notes'] ?? '')), $now, $now]
        );
    }
    audit_write('log_call', 'call', $id);
    json_out([
        'success' => true,
        'message' => 'Call log saved successfully.',
        'data' => ['id' => (string) $id, 'lead_id' => (string) $lead['id'], 'outcome' => $outcome, 'next_follow_up_at' => iso_dt($due)],
    ], 201);
}

function handle_calls_list()
{
    $user = require_user();
    [$where, $params] = activity_scope($user, 'c');
    $rows = db_all(
        "SELECT c.*, l.full_name AS lead_name, l.mobile, u.full_name AS employee_name
         FROM lead_calls c
         JOIN leads l ON l.id = c.lead_id
         JOIN users u ON u.id = c.employee_id
         WHERE $where
         ORDER BY c.started_at DESC
         LIMIT 500",
        $params
    );
    json_ok(array_map('shape_call', $rows));
}

function handle_calls_analytics()
{
    $user = require_user();
    [$where, $params] = activity_scope($user, 'c');
    $outcomes = db_all(
        "SELECT c.outcome, COUNT(*) AS cnt FROM lead_calls c WHERE $where GROUP BY c.outcome ORDER BY cnt DESC",
        $params
    );
    $employees = db_all(
        "SELECT u.id, u.full_name, COUNT(*) AS calls_logged
         FROM lead_calls c JOIN users u ON u.id = c.employee_id
         WHERE $where GROUP BY u.id, u.full_name ORDER BY calls_logged DESC",
        $params
    );
    json_ok([
        'by_outcome' => array_map(function ($row) {
            return ['outcome' => $row['outcome'], 'cnt' => (int) $row['cnt']];
        }, $outcomes),
        'by_employee' => array_map(function ($row) {
            return ['id' => (string) $row['id'], 'full_name' => $row['full_name'], 'calls_logged' => (int) $row['calls_logged']];
        }, $employees),
        'note' => 'Logged outcomes are employee-reported. A telephony provider is not connected, so duration is not independently verified.',
    ]);
}

function followup_status($row)
{
    if ($row['status'] === 'completed' || $row['status'] === 'cancelled') {
        return $row['status'];
    }
    if (strtotime($row['due_at'] . ' UTC') < time()) {
        return 'overdue';
    }
    return 'pending';
}

function shape_followup($row)
{
    return [
        'id' => (string) $row['id'],
        'title' => $row['title'],
        'lead_id' => (string) $row['lead_id'],
        'lead_name' => $row['lead_name'] ?? '',
        'mobile' => $row['mobile'] ?? '',
        'owner_name' => $row['owner_name'] ?? '',
        'due_at' => iso_dt($row['due_at']),
        'status' => followup_status($row),
        'task_type' => $row['task_type'],
        'priority' => $row['priority'],
        'notes' => $row['notes'] ?? '',
    ];
}

function handle_followups_create()
{
    $user = require_user();
    $body = request_data();
    $title = trim((string) ($body['title'] ?? ''));
    $due = $body['due_at'] ?? null;
    if ($title === '' || !$due || empty($body['lead_id'])) {
        throw new HttpError('Lead, title and due date are required.', 400);
    }
    $lead = find_visible_lead_for_activity($user, int_id($body['lead_id'], 'lead ID'));
    $types = ['call', 'whatsapp', 'email', 'meeting', 'site_visit', 'other'];
    $priorities = ['low', 'medium', 'high', 'urgent'];
    $type = in_array($body['task_type'] ?? 'call', $types, true) ? $body['task_type'] : 'call';
    $priority = in_array($body['priority'] ?? 'medium', $priorities, true) ? $body['priority'] : 'medium';
    $dueSql = sql_dt($due);
    $owner = (int) ($lead['owner_id'] ?: $user['id']);
    $id = db_insert(
        'INSERT INTO follow_ups (company_id, lead_id, employee_id, created_by, title, task_type, priority, due_at, status, notes, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, \'pending\', ?, ?, ?)',
        [(int) $lead['company_id'], (int) $lead['id'], $owner, (int) $user['id'], $title, $type, $priority, $dueSql, trim((string) ($body['notes'] ?? '')), utc_now(), utc_now()]
    );
    db_exec('UPDATE leads SET next_follow_up_at = ? WHERE id = ?', [$dueSql, (int) $lead['id']]);
    audit_write('create_follow_up', 'follow_up', $id);
    json_out(['success' => true, 'data' => ['id' => (string) $id]], 201);
}

function handle_followups_list()
{
    $user = require_user();
    [$where, $params] = activity_scope($user, 'f');
    $rows = db_all(
        "SELECT f.*, l.full_name AS lead_name, l.mobile, u.full_name AS owner_name
         FROM follow_ups f
         JOIN leads l ON l.id = f.lead_id
         JOIN users u ON u.id = f.employee_id
         WHERE $where
         ORDER BY f.due_at ASC
         LIMIT 500",
        $params
    );
    $status = $_GET['status'] ?? '';
    $shaped = array_map('shape_followup', $rows);
    if ($status !== '') {
        $shaped = array_values(array_filter($shaped, function ($row) use ($status) {
            return $row['status'] === $status;
        }));
    }
    json_ok($shaped);
}

function handle_followup_update($id)
{
    $user = require_user();
    $followId = int_id($id, 'follow-up ID');
    [$where, $params] = activity_scope($user, 'f');
    $params[] = $followId;
    $row = db_one("SELECT f.* FROM follow_ups f WHERE $where AND f.id = ?", $params);
    if (!$row) {
        throw new HttpError('Follow-up not found.', 404);
    }
    $body = request_data();
    $status = (string) ($body['status'] ?? 'completed');
    if (!in_array($status, ['pending', 'completed', 'cancelled'], true)) {
        throw new HttpError('Invalid follow-up status.', 400);
    }
    db_exec(
        'UPDATE follow_ups SET status = ?, completed_at = ?, notes = COALESCE(?, notes) WHERE id = ?',
        [$status, $status === 'completed' ? utc_now() : null, isset($body['notes']) ? trim((string) $body['notes']) : null, $followId]
    );
    audit_write('update_follow_up', 'follow_up', $followId);
    json_ok(['id' => (string) $followId, 'status' => $status]);
}

function handle_followups_escalate()
{
    $user = require_user();
    if (!in_array($user['role'], ['admin', 'team_lead'], true)) {
        throw new HttpError('Only Admins and Team Leads can escalate follow-ups.', 403);
    }
    [$where, $params] = activity_scope($user, 'f');
    $rows = db_all("SELECT f.*, l.full_name AS lead_name FROM follow_ups f JOIN leads l ON l.id = f.lead_id WHERE $where AND f.status = 'pending' AND f.due_at < ?", array_merge($params, [utc_now()]));
    $count = 0;
    foreach ($rows as $row) {
        db_exec('UPDATE follow_ups SET escalated_at = ? WHERE id = ?', [utc_now(), (int) $row['id']]);
        notify_user((int) $row['employee_id'], 'Follow-up escalated', $row['lead_name'] . ' is overdue.', '/follow-ups');
        $count++;
    }
    audit_write('escalate_follow_ups', 'follow_up', null);
    json_ok(['escalated' => $count]);
}

function handle_visits_create()
{
    $user = require_user();
    $body = request_data();
    if (empty($body['lead_id']) || empty($body['scheduled_at'])) {
        throw new HttpError('Lead and scheduled time are required.', 400);
    }
    $lead = find_visible_lead_for_activity($user, int_id($body['lead_id'], 'lead ID'));
    $owner = (int) ($lead['owner_id'] ?: $user['id']);
    $id = db_insert(
        'INSERT INTO site_visits (company_id, lead_id, employee_id, created_by, property_name, scheduled_at, status, notes, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, \'scheduled\', ?, ?, ?)',
        [
            (int) $lead['company_id'],
            (int) $lead['id'],
            $owner,
            (int) $user['id'],
            trim((string) ($body['property_name'] ?? '')),
            sql_dt($body['scheduled_at']),
            trim((string) ($body['notes'] ?? '')),
            utc_now(),
            utc_now(),
        ]
    );
    audit_write('schedule_visit', 'site_visit', $id);
    json_out(['success' => true, 'data' => ['id' => (string) $id]], 201);
}

function shape_visit($row)
{
    return [
        'id' => (string) $row['id'],
        'lead_id' => (string) $row['lead_id'],
        'lead_name' => $row['lead_name'] ?? '',
        'mobile' => $row['mobile'] ?? '',
        'owner_name' => $row['owner_name'] ?? '',
        'property_name' => $row['property_name'] ?? '',
        'scheduled_at' => iso_dt($row['scheduled_at']),
        'status' => $row['status'],
        'notes' => $row['notes'] ?? '',
        'feedback' => $row['feedback'] ?? '',
    ];
}

function handle_visits_list()
{
    $user = require_user();
    [$where, $params] = activity_scope($user, 'v');
    $rows = db_all(
        "SELECT v.*, l.full_name AS lead_name, l.mobile, u.full_name AS owner_name
         FROM site_visits v
         JOIN leads l ON l.id = v.lead_id
         JOIN users u ON u.id = v.employee_id
         WHERE $where
         ORDER BY v.scheduled_at ASC
         LIMIT 500",
        $params
    );
    json_ok(array_map('shape_visit', $rows));
}

function handle_visit_update($id)
{
    $user = require_user();
    $visitId = int_id($id, 'site visit ID');
    [$where, $params] = activity_scope($user, 'v');
    $params[] = $visitId;
    $row = db_one("SELECT v.* FROM site_visits v WHERE $where AND v.id = ?", $params);
    if (!$row) {
        throw new HttpError('Site visit not found.', 404);
    }
    $body = request_data();
    $status = (string) ($body['status'] ?? 'completed');
    $allowed = ['scheduled', 'completed', 'cancelled', 'rescheduled', 'no_show'];
    if (!in_array($status, $allowed, true)) {
        throw new HttpError('Invalid site visit status.', 400);
    }
    db_exec(
        'UPDATE site_visits SET status = ?, feedback = COALESCE(?, feedback), notes = COALESCE(?, notes), completed_at = ? WHERE id = ?',
        [
            $status,
            isset($body['feedback']) ? trim((string) $body['feedback']) : null,
            isset($body['notes']) ? trim((string) $body['notes']) : null,
            $status === 'completed' ? utc_now() : null,
            $visitId,
        ]
    );
    audit_write('update_visit', 'site_visit', $visitId);
    json_ok(['id' => (string) $visitId, 'status' => $status]);
}
