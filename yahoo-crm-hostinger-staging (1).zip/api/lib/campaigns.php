<?php

function campaign_managers()
{
    return ['super_admin', 'admin'];
}

function require_campaign_manager()
{
    $user = require_user();
    if (!in_array($user['role'], campaign_managers(), true)) {
        throw new HttpError('Only Admins can manage drip campaigns.', 403);
    }
    return $user;
}

function campaign_rows($user)
{
    if ($user['role'] === 'super_admin') {
        return db_all('SELECT * FROM drip_campaigns ORDER BY updated_at DESC');
    }
    if (empty($user['company_id'])) {
        return db_all('SELECT * FROM drip_campaigns WHERE created_by = ? ORDER BY updated_at DESC', [(int) $user['id']]);
    }
    return db_all(
        'SELECT * FROM drip_campaigns WHERE company_id = ? OR (created_by = ? AND company_id IS NULL) ORDER BY updated_at DESC',
        [(int) $user['company_id'], (int) $user['id']]
    );
}

function format_campaign($row)
{
    $steps = json_decode($row['steps_json'] ?? '[]', true);
    if (!is_array($steps)) {
        $steps = [];
    }
    $steps = array_map(function ($step) {
        $minutes = (int) ($step['delay_minutes'] ?? 0);
        return [
            'step_number' => (int) ($step['step_number'] ?? 1),
            'delay_minutes' => $minutes,
            'delay_days' => round($minutes / 1440, 2),
            'template_name' => $step['template_name'] ?? '',
            'language_code' => $step['language_code'] ?? 'en',
            'is_active' => ($step['is_active'] ?? true) !== false,
        ];
    }, $steps);
    return [
        'id' => (string) $row['id'],
        '_id' => (string) $row['id'],
        'name' => $row['name'],
        'description' => $row['description'],
        'trigger' => $row['trigger_type'],
        'trigger_status_id' => $row['trigger_status_id'] !== null ? (int) $row['trigger_status_id'] : null,
        'steps' => $steps,
        'status' => $row['status'],
        'company_id' => $row['company_id'] ? (string) $row['company_id'] : null,
        'created_by' => (string) $row['created_by'],
        'created_at' => iso_dt($row['created_at']),
        'updated_at' => iso_dt($row['updated_at']),
    ];
}

function validate_steps($steps)
{
    if (!is_array($steps) || count($steps) === 0) {
        throw new HttpError('Add at least one message step.', 400);
    }
    if (count($steps) > 20) {
        throw new HttpError('A campaign can have at most 20 steps.', 400);
    }
    $clean = [];
    foreach ($steps as $i => $step) {
        $delay = (int) ($step['delay_minutes'] ?? -1);
        if ($delay < 0 || $delay > 525600) {
            throw new HttpError('Step ' . ($i + 1) . ' must have a valid delay in minutes.', 400);
        }
        $template = trim((string) ($step['template_name'] ?? ''));
        if (!preg_match('/^[a-zA-Z0-9_]+$/', $template)) {
            throw new HttpError('Step ' . ($i + 1) . ' must have a valid WhatsApp template name.', 400);
        }
        $language = $step['language_code'] ?? 'en';
        if (!preg_match('/^[a-z]{2,3}(?:_[A-Z]{2})?$/', (string) $language)) {
            throw new HttpError('Step ' . ($i + 1) . ' has an invalid language code.', 400);
        }
        $clean[] = [
            'step_number' => $i + 1,
            'delay_minutes' => $delay,
            'template_name' => $template,
            'language_code' => $language,
            'is_active' => ($step['is_active'] ?? true) !== false,
        ];
    }
    return $clean;
}

function load_campaign($user, $id)
{
    $campaignId = int_id($id, 'campaign ID');
    $rows = campaign_rows($user);
    foreach ($rows as $row) {
        if ((int) $row['id'] === $campaignId) {
            return $row;
        }
    }
    throw new HttpError('Campaign not found.', 404);
}

function handle_campaigns_list()
{
    $user = require_campaign_manager();
    json_ok(array_map('format_campaign', campaign_rows($user)));
}

function handle_campaign_get($id)
{
    $user = require_campaign_manager();
    json_ok(format_campaign(load_campaign($user, $id)));
}

function handle_campaign_create()
{
    $user = require_campaign_manager();
    $body = request_data();
    $name = trim((string) ($body['name'] ?? ''));
    $description = (string) ($body['description'] ?? '');
    if ($name === '') {
        throw new HttpError('Campaign name is required.', 400);
    }
    if (strlen($name) > 120 || strlen($description) > 1000) {
        throw new HttpError('Campaign name or description is too long.', 400);
    }
    $trigger = (string) ($body['trigger'] ?? 'manual');
    if (!in_array($trigger, ['manual', 'new_lead', 'status_change'], true)) {
        throw new HttpError('Invalid campaign trigger.', 400);
    }
    $steps = validate_steps($body['steps'] ?? []);
    $statusId = $body['trigger_status_id'] ?? null;
    $id = db_insert(
        'INSERT INTO drip_campaigns (company_id, name, description, trigger_type, trigger_status_id, steps_json, status, created_by, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, \'draft\', ?, ?, ?)',
        [
            $user['company_id'] ?: null,
            $name,
            $description,
            $trigger,
            $statusId === null || $statusId === '' ? null : (int) $statusId,
            json_encode($steps),
            (int) $user['id'],
            utc_now(),
            utc_now(),
        ]
    );
    audit_write('create_campaign', 'campaign', $id);
    $row = db_one('SELECT * FROM drip_campaigns WHERE id = ?', [$id]);
    json_out(['success' => true, 'message' => 'Campaign saved as a draft.', 'data' => format_campaign($row)], 201);
}

function handle_campaign_update($id)
{
    $user = require_campaign_manager();
    $row = load_campaign($user, $id);
    if ($row['status'] === 'active') {
        throw new HttpError('Pause the campaign before editing it.', 409);
    }
    $body = request_data();
    $name = $row['name'];
    $description = $row['description'];
    $trigger = $row['trigger_type'];
    $statusId = $row['trigger_status_id'];
    $steps = json_decode($row['steps_json'], true) ?: [];
    if (array_key_exists('name', $body)) {
        $name = trim((string) $body['name']);
        if ($name === '' || strlen($name) > 120) {
            throw new HttpError('Campaign name is required and must be under 120 characters.', 400);
        }
    }
    if (array_key_exists('description', $body)) {
        $description = (string) $body['description'];
        if (strlen($description) > 1000) {
            throw new HttpError('Description must be under 1,000 characters.', 400);
        }
    }
    if (array_key_exists('trigger', $body)) {
        $trigger = (string) $body['trigger'];
        if (!in_array($trigger, ['manual', 'new_lead', 'status_change'], true)) {
            throw new HttpError('Invalid campaign trigger.', 400);
        }
    }
    if (array_key_exists('trigger_status_id', $body)) {
        $statusId = $body['trigger_status_id'];
        $statusId = $statusId === null || $statusId === '' ? null : (int) $statusId;
    }
    if ($trigger === 'status_change' && ($statusId === null || $statusId < 1 || $statusId > 5)) {
        throw new HttpError('Choose a valid lead status for this trigger.', 400);
    }
    if (array_key_exists('steps', $body)) {
        $steps = validate_steps($body['steps']);
    }
    db_exec(
        'UPDATE drip_campaigns SET name = ?, description = ?, trigger_type = ?, trigger_status_id = ?, steps_json = ? WHERE id = ?',
        [$name, $description, $trigger, $statusId, json_encode($steps), (int) $row['id']]
    );
    audit_write('update_campaign', 'campaign', $row['id']);
    json_ok(format_campaign(db_one('SELECT * FROM drip_campaigns WHERE id = ?', [(int) $row['id']])));
}

function handle_campaign_status($id, $status)
{
    $user = require_campaign_manager();
    $row = load_campaign($user, $id);
    if ($status === 'active') {
        $steps = json_decode($row['steps_json'], true);
        $active = array_filter($steps ?: [], function ($step) {
            return ($step['is_active'] ?? true) !== false;
        });
        if (!$active) {
            throw new HttpError('Add an active message step before activating the campaign.', 400);
        }
    }
    db_exec('UPDATE drip_campaigns SET status = ? WHERE id = ?', [$status, (int) $row['id']]);
    audit_write($status === 'active' ? 'activate_campaign' : 'pause_campaign', 'campaign', $row['id']);
    json_ok(format_campaign(db_one('SELECT * FROM drip_campaigns WHERE id = ?', [(int) $row['id']])));
}

function handle_campaign_enroll($id)
{
    $user = require_campaign_manager();
    $row = load_campaign($user, $id);
    if ($row['status'] !== 'active') {
        throw new HttpError('Activate the campaign before enrolling leads.', 409);
    }
    $body = request_data();
    $leadIds = $body['lead_ids'] ?? null;
    if (!is_array($leadIds) || count($leadIds) < 1 || count($leadIds) > 100) {
        throw new HttpError('Provide between 1 and 100 lead IDs.', 400);
    }
    $steps = json_decode($row['steps_json'], true) ?: [];
    usort($steps, function ($a, $b) {
        return ($a['step_number'] ?? 0) <=> ($b['step_number'] ?? 0);
    });
    $first = null;
    foreach ($steps as $step) {
        if (($step['is_active'] ?? true) !== false) {
            $first = $step;
            break;
        }
    }
    if (!$first) {
        throw new HttpError('This campaign has no active message steps.', 400);
    }
    $results = [];
    foreach ($leadIds as $leadId) {
        $lead = db_one('SELECT * FROM leads WHERE id = ? AND consent_whatsapp = 1', [int_id($leadId, 'lead ID')]);
        if (!$lead || ($user['role'] !== 'super_admin' && (int) $lead['company_id'] !== (int) $user['company_id'])) {
            throw new HttpError('Some leads do not exist or have not granted WhatsApp consent.', 400);
        }
        $existing = db_one('SELECT id FROM drip_enrollments WHERE campaign_id = ? AND lead_id = ?', [(int) $row['id'], (int) $lead['id']]);
        if ($existing) {
            $results[] = ['lead_id' => (string) $lead['id'], 'status' => 'already_enrolled'];
            continue;
        }
        $next = gmdate('Y-m-d H:i:s', time() + ((int) $first['delay_minutes']) * 60);
        db_insert(
            'INSERT INTO drip_enrollments (campaign_id, lead_id, company_id, current_step, status, next_message_at, enrolled_by, created_at, updated_at)
             VALUES (?, ?, ?, ?, \'active\', ?, ?, ?, ?)',
            [(int) $row['id'], (int) $lead['id'], $lead['company_id'], (int) $first['step_number'], $next, (int) $user['id'], utc_now(), utc_now()]
        );
        $results[] = ['lead_id' => (string) $lead['id'], 'status' => 'enrolled_test_mode'];
    }
    audit_write('enroll_campaign', 'campaign', $row['id']);
    json_out([
        'success' => true,
        'data' => $results,
        'message' => 'Enrollments recorded. WhatsApp sending is not enabled.',
    ], 201);
}

function handle_campaign_enrollments($id)
{
    $user = require_campaign_manager();
    $row = load_campaign($user, $id);
    $rows = db_all(
        'SELECT e.*, l.full_name, l.mobile FROM drip_enrollments e JOIN leads l ON l.id = e.lead_id WHERE e.campaign_id = ? ORDER BY e.enrolled_at DESC',
        [(int) $row['id']]
    );
    json_ok(array_map(function ($item) {
        return [
            'id' => (string) $item['id'],
            'lead_id' => (string) $item['lead_id'],
            'full_name' => $item['full_name'],
            'mobile' => $item['mobile'],
            'status' => $item['status'],
            'current_step' => (int) $item['current_step'],
            'next_message_at' => iso_dt($item['next_message_at']),
            'enrolled_at' => iso_dt($item['enrolled_at']),
        ];
    }, $rows));
}
