<?php

ini_set('display_errors', '0');
ini_set('log_errors', '1');
date_default_timezone_set('UTC');
header_remove('X-Powered-By');

define('APP_ROOT', dirname(__DIR__));

require __DIR__ . '/lib/http.php';
require __DIR__ . '/lib/db.php';
require __DIR__ . '/lib/auth.php';
require __DIR__ . '/lib/companies.php';
require __DIR__ . '/lib/users.php';
require __DIR__ . '/lib/leads.php';
require __DIR__ . '/lib/activity.php';
require __DIR__ . '/lib/attendance.php';
require __DIR__ . '/lib/campaigns.php';
require __DIR__ . '/lib/dashboard.php';
require __DIR__ . '/lib/extras.php';

if (strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    load_session();
    verify_csrf();
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    $path = api_path();
    dispatch($method, $path);
    json_error('That API route does not exist.', 404);
} catch (HttpError $error) {
    json_error($error->getMessage(), $error->getCode() ?: 400);
} catch (PDOException $error) {
    error_log('Yahoo CRM database error: ' . $error->getMessage());
    json_error('The database request could not be completed.', 500);
} catch (Throwable $error) {
    error_log('Yahoo CRM error: ' . $error->getMessage());
    json_error('The request could not be completed.', 500);
}

function dispatch($method, $path)
{
    if ($method === 'GET' && $path === '/health') {
        handle_health();
    }

    if ($method === 'POST' && $path === '/auth/login') {
        handle_login();
    }
    if ($method === 'GET' && $path === '/auth/me') {
        handle_me();
    }
    if ($method === 'POST' && $path === '/auth/logout') {
        handle_logout();
    }
    if ($method === 'POST' && $path === '/auth/change-password') {
        handle_change_password();
    }

    if ($method === 'GET' && $path === '/companies') {
        handle_companies_list();
    }
    if ($method === 'POST' && $path === '/companies') {
        handle_company_create();
    }
    if (preg_match('#^/companies/(\d+)/status$#', $path, $match) && $method === 'PATCH') {
        handle_company_status($match[1]);
    }
    if (preg_match('#^/companies/(\d+)$#', $path, $match) && in_array($method, ['PUT', 'PATCH'], true)) {
        handle_company_update($match[1]);
    }

    if ($method === 'GET' && $path === '/company-admins') {
        handle_company_admins_list();
    }
    if ($method === 'POST' && $path === '/company-admins') {
        handle_company_admin_create();
    }
    if (preg_match('#^/company-admins/(\d+)/status$#', $path, $match) && $method === 'PATCH') {
        handle_company_admin_status($match[1]);
    }
    if (preg_match('#^/company-admins/(\d+)/assign-company$#', $path, $match) && in_array($method, ['POST', 'PATCH'], true)) {
        handle_company_admin_assign($match[1]);
    }

    if ($method === 'GET' && $path === '/users') {
        handle_users_list();
    }
    if ($method === 'POST' && $path === '/users') {
        handle_user_create();
    }
    if (preg_match('#^/users/(\d+)/status$#', $path, $match) && $method === 'PATCH') {
        handle_user_status($match[1]);
    }
    if (preg_match('#^/users/(\d+)$#', $path, $match)) {
        if ($method === 'GET') {
            handle_user_get($match[1]);
        }
        if (in_array($method, ['PUT', 'PATCH'], true)) {
            handle_user_update($match[1]);
        }
    }

    if ($method === 'GET' && $path === '/leads/meta') {
        handle_leads_meta();
    }
    if ($method === 'GET' && $path === '/leads') {
        handle_leads_list();
    }
    if ($method === 'POST' && $path === '/leads') {
        handle_lead_create();
    }
    if ($method === 'GET' && $path === '/leads/export') {
        handle_leads_export();
    }
    if ($method === 'POST' && $path === '/leads/import') {
        handle_leads_import();
    }
    if (preg_match('#^/leads/(\d+)$#', $path, $match)) {
        if ($method === 'GET') {
            handle_lead_get($match[1]);
        }
        if (in_array($method, ['PUT', 'PATCH'], true)) {
            handle_lead_update($match[1]);
        }
    }
    if (preg_match('#^/leads/(\d+)/assign$#', $path, $match) && $method === 'POST') {
        handle_lead_assign($match[1]);
    }
    if (preg_match('#^/leads/(\d+)/notes$#', $path, $match) && $method === 'POST') {
        handle_lead_note($match[1]);
    }
    if (preg_match('#^/leads/(\d+)/calls$#', $path, $match) && $method === 'GET') {
        handle_lead_calls($match[1]);
    }
    if (preg_match('#^/leads/(\d+)/calls/end$#', $path, $match) && $method === 'POST') {
        handle_lead_call_end($match[1]);
    }

    if ($method === 'GET' && $path === '/calls') {
        handle_calls_list();
    }
    if ($method === 'POST' && $path === '/calls') {
        handle_calls_create();
    }
    if ($method === 'GET' && $path === '/calls/analytics') {
        handle_calls_analytics();
    }

    if ($method === 'GET' && $path === '/follow-ups') {
        handle_followups_list();
    }
    if ($method === 'POST' && $path === '/follow-ups') {
        handle_followups_create();
    }
    if ($method === 'POST' && $path === '/follow-ups/escalate') {
        handle_followups_escalate();
    }
    if (preg_match('#^/follow-ups/(\d+)$#', $path, $match) && in_array($method, ['PUT', 'PATCH'], true)) {
        handle_followup_update($match[1]);
    }

    if ($method === 'GET' && $path === '/site-visits') {
        handle_visits_list();
    }
    if ($method === 'POST' && $path === '/site-visits') {
        handle_visits_create();
    }
    if (preg_match('#^/site-visits/(\d+)$#', $path, $match) && in_array($method, ['PUT', 'PATCH'], true)) {
        handle_visit_update($match[1]);
    }

    if ($method === 'POST' && $path === '/attendance/check-in') {
        handle_check_in();
    }
    if ($method === 'POST' && $path === '/attendance/check-out') {
        handle_check_out();
    }
    if ($method === 'GET' && $path === '/attendance/me/today') {
        handle_attendance_today();
    }
    if ($method === 'POST' && $path === '/attendance/breaks/start') {
        handle_break_start();
    }
    if ($method === 'POST' && $path === '/attendance/breaks/end') {
        handle_break_end();
    }
    if ($method === 'GET' && $path === '/attendance') {
        handle_attendance_list();
    }
    if ($method === 'GET' && $path === '/attendance/summary') {
        handle_attendance_summary();
    }

    if ($method === 'GET' && $path === '/campaigns') {
        handle_campaigns_list();
    }
    if ($method === 'POST' && $path === '/campaigns') {
        handle_campaign_create();
    }
    if (preg_match('#^/campaigns/(\d+)$#', $path, $match) && $method === 'GET') {
        handle_campaign_get($match[1]);
    }
    if (preg_match('#^/campaigns/(\d+)$#', $path, $match) && $method === 'PATCH') {
        handle_campaign_update($match[1]);
    }
    if (preg_match('#^/campaigns/(\d+)/activate$#', $path, $match) && $method === 'POST') {
        handle_campaign_status($match[1], 'active');
    }
    if (preg_match('#^/campaigns/(\d+)/pause$#', $path, $match) && $method === 'POST') {
        handle_campaign_status($match[1], 'paused');
    }
    if (preg_match('#^/campaigns/(\d+)/enroll$#', $path, $match) && $method === 'POST') {
        handle_campaign_enroll($match[1]);
    }
    if (preg_match('#^/campaigns/(\d+)/enrollments$#', $path, $match) && $method === 'GET') {
        handle_campaign_enrollments($match[1]);
    }

    if ($method === 'GET' && $path === '/dashboard') {
        handle_dashboard();
    }
    if ($method === 'GET' && $path === '/reports/companies') {
        handle_reports_companies();
    }
    if (preg_match('#^/reports/company/(\d+)$#', $path, $match) && $method === 'GET') {
        handle_report_company($match[1]);
    }
    if ($method === 'GET' && $path === '/reports/my-performance') {
        handle_my_performance();
    }

    if ($method === 'GET' && $path === '/teams') {
        handle_teams_list();
    }
    if ($method === 'POST' && $path === '/teams') {
        handle_team_create();
    }
    if (preg_match('#^/teams/(\d+)/members$#', $path, $match) && $method === 'GET') {
        handle_team_members($match[1]);
    }

    if ($method === 'GET' && $path === '/properties') {
        handle_properties_list();
    }
    if ($method === 'POST' && $path === '/properties') {
        handle_property_create();
    }
    if (preg_match('#^/properties/(\d+)/matches$#', $path, $match) && $method === 'GET') {
        handle_property_matches($match[1]);
    }

    if ($method === 'GET' && $path === '/notifications') {
        handle_notifications_list();
    }
    if ($method === 'POST' && $path === '/notifications/read-all') {
        handle_notifications_read_all();
    }
    if (preg_match('#^/notifications/(\d+)/read$#', $path, $match) && $method === 'POST') {
        handle_notification_read($match[1]);
    }

    if ($method === 'GET' && $path === '/settings') {
        handle_settings_get();
    }
    if ($method === 'POST' && $path === '/settings') {
        handle_settings_save();
    }
    if ($method === 'GET' && $path === '/settings/assignment-rules') {
        handle_assignment_rules();
    }
    if ($method === 'GET' && $path === '/settings/queues') {
        handle_assignment_queues();
    }
    if ($method === 'POST' && $path === '/settings/queues/pause') {
        handle_queue_pause();
    }
    if ($method === 'POST' && $path === '/settings/queues/reset') {
        handle_queue_reset();
    }

    if ($method === 'GET' && $path === '/nurturing') {
        handle_nurturing_list();
    }
    if (preg_match('#^/nurturing/(\d+)/toggle$#', $path, $match) && $method === 'POST') {
        handle_nurturing_toggle($match[1]);
    }

    if ($method === 'GET' && $path === '/audit-logs') {
        handle_audit_logs();
    }
    if ($method === 'GET' && $path === '/whatsapp/status') {
        handle_whatsapp_status();
    }
    if ($method === 'POST' && $path === '/whatsapp/send') {
        handle_whatsapp_send();
    }

    if ($method === 'GET' && $path === '/employee/workspace') {
        handle_employee_workspace();
    }
    if ($method === 'GET' && $path === '/employee/attendance') {
        handle_employee_attendance();
    }
}
