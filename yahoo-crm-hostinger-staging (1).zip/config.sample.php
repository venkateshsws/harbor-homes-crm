<?php

// Copy this file to config.php and fill in the Hostinger MySQL database.
// .htaccess denies this file. This guard also stops PHP from printing it
// if the file is requested directly.

if (PHP_SAPI !== 'cli' && isset($_SERVER['SCRIPT_FILENAME']) && realpath($_SERVER['SCRIPT_FILENAME']) === realpath(__FILE__)) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    exit("Forbidden\n");
}

return [
    'db_host' => 'localhost',
    'db_name' => '',
    'db_user' => '',
    'db_pass' => '',
    'session_ttl_hours' => 12,
    // Random string of at least 16 characters. Required by setup.php, then delete setup.php.
    'setup_key' => '',
];
